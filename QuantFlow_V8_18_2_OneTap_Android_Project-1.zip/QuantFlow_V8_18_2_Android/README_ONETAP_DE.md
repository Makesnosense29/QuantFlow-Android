# QuantFlow V8.18.2-forward – One-Tap Android App

Diese Variante ist als normale Android-App gedacht: **App-Symbol antippen → QuantFlow öffnet sich → Paper-Bot startet automatisch → Dashboard erscheint.**

Es ist kein Termux-Befehl und kein Browser-Link nötig. Beim Zurückgehen oder Wechseln zu einer anderen App bleibt der Bot über einen Android-Foreground-Service aktiv. Die dauerhafte Android-Benachrichtigung zeigt an, dass der Paper-Bot läuft.

## Verhalten

- Einmaliges Antippen des App-Symbols startet bzw. öffnet QuantFlow.
- Wenn der Bot bereits läuft, öffnet sich direkt das lokale Dashboard.
- Beim ersten Start erscheint kurz ein QuantFlow-Ladebildschirm, bis `127.0.0.1:8766` bereit ist.
- Die V8.18.2-forward Strategie ist unverändert und bleibt PAPER only.
- Über das Android-Menü gibt es nur Wartungsfunktionen: Dashboard neu laden, Bot neu starten, Bot stoppen und Akku-Einstellungen.
- Android-Zurück legt die App in den Hintergrund; der Bot läuft weiter.

## Installation

Nach dem Build wird `app-debug.apk` bzw. eine signierte Release-APK wie jede andere Android-App installiert. Danach erscheint **QuantFlow** im App-Drawer/Startbildschirm und wird mit einem normalen Tap geöffnet.

Für zuverlässigen Dauerbetrieb sollte Android für QuantFlow die Akkuoptimierung nicht aggressiv einschränken.
