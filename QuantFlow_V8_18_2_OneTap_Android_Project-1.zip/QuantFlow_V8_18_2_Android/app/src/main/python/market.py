"""Persistent discovery universe plus fair global selection of real addresses."""
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
from pathlib import Path
import json
import math
import os
import threading
import time
from chains import normalize
from pool_discovery import PoolCrawler

class Universe:
    def __init__(self,path=None):
        self.path=Path(path) if path else None
        self.tokens={};self.selected={};self.refreshed=0;self.round=0;self.errors=[]
        self.lock=threading.RLock();self.stop=threading.Event();self.worker=None
        self.cursor=0;self.pool_pages=0;self.pool_error=None;self.crawled_cursor=0
        if self.path and self.path.exists():
            try:
                saved=json.loads(self.path.read_text())
                self.tokens=saved['tokens'];self.cursor=int(saved.get('cursor',0));self.round=int(saved.get('round',0))
                if not isinstance(self.tokens,dict):raise ValueError('tokens')
            except Exception as exc:raise ValueError('universe.json unlesbar; Datei prüfen statt zurücksetzen') from exc
    def add(self,chain,tokens,now,cap):
        with self.lock:
            bucket=self.tokens.setdefault(chain,{})
            for token in tokens:bucket[normalize(chain,token)]=now
            self.tokens[chain]=dict(sorted(((t,s) for t,s in bucket.items() if math.isfinite(float(s)) and now-float(s)<172800),key=lambda x:x[1],reverse=True)[:cap])
    def save(self):
        if self.path:
            with self.lock:
                tmp=self.path.with_suffix('.tmp')
                tmp.write_text(json.dumps({'tokens':self.tokens,'cursor':self.cursor,'round':self.round}))
                os.replace(tmp,self.path)
    def start(self,config):
        if self.stop.is_set() or not self.path or self.worker is not None or not config.get('pool_discovery_enabled',True):return
        def run():
            crawler=PoolCrawler(self.cursor)
            while not self.stop.is_set():
                delay=float(config['pool_request_interval_seconds'])
                try:
                    chain,tokens=crawler.step(config['enabled_chains'],config['pool_pages_per_network'])
                    self.add(chain,tokens,time.time(),config['max_universe_per_chain'])
                    self.cursor=crawler.cursor;self.pool_pages=crawler.pages;self.pool_error=None
                    self.save()
                except Exception as exc:
                    self.pool_error=type(exc).__name__
                    # Skip a failed page after backoff; unavailable chains cannot starve others.
                    crawler.cursor+=1;self.cursor=crawler.cursor
                    delay=max(delay,60)
                self.stop.wait(delay)
        self.worker=threading.Thread(target=run,name='pool-discovery',daemon=True);self.worker.start()
    def close(self):
        self.stop.set()
        if self.worker:self.worker.join(timeout=9)
    @staticmethod
    def _rotate(items,offset):
        if not items:return []
        offset%=len(items)
        return items[offset:]+items[:offset]
    def select(self,config,now):
        """Select a globally bounded universe with a fresh-token bias and rotation.

        V8.18 previously sorted addresses lexicographically, so discovery recency was
        thrown away.  With a 48h registry that can spend most scanner slots on stale
        addresses.  Keep most slots inside the freshest part of each chain, but rotate
        both the fresh and older pools so no token is permanently starved.
        """
        chains=config['enabled_chains'];limit=config['max_candidates_per_chain'];budget=config.get('max_scan_candidates',limit*len(chains))
        total_budget=int(budget)
        share=max(1,math.ceil(total_budget/max(1,len(chains))))
        target=min(limit,share)
        fresh_share=float(config.get('fresh_selection_share',0.70))
        fresh_share=min(0.90,max(0.50,fresh_share))
        fresh_pool_mult=max(1.0,float(config.get('fresh_selection_pool_multiplier',3.0)))
        with self.lock:
            self.selected={c:[] for c in chains}
            lists={}
            for c in chains:
                self.add(c,config.get('watchlist',{}).get(c,[]),now,config['max_universe_per_chain'])
                # Timestamp first, token second for deterministic ties.
                ranked=[token for token,_ in sorted(self.tokens.get(c,{}).items(),key=lambda kv:(-float(kv[1]),kv[0]))]
                if not ranked:
                    lists[c]=[];continue
                pool_n=min(len(ranked),max(target,int(math.ceil(target*fresh_pool_mult))))
                fresh_pool=ranked[:pool_n];older_pool=ranked[pool_n:]
                fresh_n=min(target,int(math.ceil(target*fresh_share)))
                old_n=max(0,target-fresh_n)
                fresh_rot=self._rotate(fresh_pool,self.round*max(1,fresh_n))
                old_rot=self._rotate(older_pool,self.round*max(1,old_n))
                primary=fresh_rot[:fresh_n]+old_rot[:old_n]
                # If the older pool is small, fill the primary quota from fresh data.
                if len(primary)<target:
                    for token in fresh_rot[fresh_n:]+old_rot[old_n:]:
                        if token not in primary:
                            primary.append(token)
                            if len(primary)>=target:break
                # Keep a rotated remainder so chains with spare global capacity can use it.
                seen=set(primary)
                remainder=[x for x in fresh_rot+old_rot if x not in seen]
                lists[c]=(primary+remainder)[:limit]
            # Allocate unused slots to chains that have more tokens; never pad with duplicates.
            budget=total_budget
            for i in range(limit):
                for c in chains:
                    if budget and i<len(lists[c]):self.selected[c].append(lists[c][i]);budget-=1
                if not budget:break
            self.round+=1
            return {c:list(ts) for c,ts in self.selected.items()}
    def status(self,config):
        with self.lock:
            known=sum(len(self.tokens.get(c,{})) for c in config['enabled_chains'])
            selected=sum(len(v) for v in self.selected.values())
            return {'target':config.get('candidate_target',1000),'known':known,'selected':selected,
                    'capacity':config.get('max_scan_candidates',1200),'pool_pages_this_run':self.pool_pages,
                    'pool_error':self.pool_error,'target_reached':selected>=config.get('candidate_target',1000)}
    def discover(self,get_json,config):
        self.start(config)
        now=time.time();chains=config['enabled_chains']
        if self.selected and now-self.refreshed<config['discovery_refresh_seconds']:
            return {c:list(ts) for c,ts in self.selected.items()}
        urls=['https://api.dexscreener.com/'+p for p in ('token-profiles/latest/v1','token-profiles/recent-updates/v1','token-boosts/top/v1','token-boosts/latest/v1')]
        queries=config['discovery_search_queries'];count=config.get('discovery_queries_per_round',4);start=self.round*count
        urls+=['https://api.dexscreener.com/latest/dex/search?q='+quote(queries[(start+i)%len(queries)],safe='') for i in range(min(count,len(queries)))]
        self.errors=[]
        def fetch(url):
            try:return get_json(url)
            except Exception as exc:return {'failure':type(exc).__name__}
        with ThreadPoolExecutor(max_workers=4) as pool:
            for data in pool.map(fetch,urls):
                if isinstance(data,dict) and 'failure' in data:self.errors.append(data['failure']);continue
                items=data.get('pairs',[]) if isinstance(data,dict) else data
                for item in items if isinstance(items,list) else []:
                    if not isinstance(item,dict):continue
                    chain=item.get('chainId');token=item.get('tokenAddress') or (item.get('baseToken') or {}).get('address')
                    if chain in chains and token:self.add(chain,[token],now,config['max_universe_per_chain'])
        selected=self.select(config,time.time());self.refreshed=time.time();self.save()
        return selected
