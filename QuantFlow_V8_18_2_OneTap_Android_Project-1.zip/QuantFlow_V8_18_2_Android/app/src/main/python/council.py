"""Ten bounded incremental challengers. Original stdlib implementations.
Scores are experimental, not calibrated profit probabilities.
All evaluation inputs must be predictions frozen at BUY, before label availability.
"""
import math
import random
from collections import deque

CATALOG = {
 'gaussian_nb': ('Gaussian Naive Bayes','Lernt Mittelwerte und Streuung je Ergebnis.'),
 'bernoulli_nb': ('Bernoulli Naive Bayes','Lernt Kombinationen binärer Merkmale.'),
 'centroid': ('Nearest Centroid','Vergleicht gelernte Gewinner-/Verlierer-Zentren.'),
 'perceptron': ('Online Perceptron','Lernt eine lineare Trennfläche aus Fehlern.'),
 'passive_aggressive': ('Passive-Aggressive I','Korrigiert zu kleine Klassifikationsabstände.'),
 'adagrad': ('AdaGrad Logistic','Lernt mit eigener Schrittweite pro Merkmal.'),
 'ftrl': ('FTRL Logistic','Lernt sparsame Gewichte mit L1-Regularisierung.'),
 'fourier': ('Fourier Logistic','Lernt nichtlineare Beziehungen in festen Zufallsmerkmalen.'),
 'histogram_nb': ('Histogram Naive Bayes','Lernt Häufigkeiten in acht Wertebereichen.'),
 'stump': ('Lernender Entscheidungsstumpf','Wählt Merkmal und Schwelle anhand gelernter Klassentrennung.')}

def sigmoid(z):return 1/(1+math.exp(-max(-30.,min(30.,z))))
def valid(x):
 if len(x)!=8 or not all(isinstance(v,(int,float)) and math.isfinite(v) and -2<=v<=2 for v in x):raise ValueError('Council benötigt acht endliche Merkmale in [-2,2]')
def bucket(v):return max(0,min(7,int((v+2)*2)))

class Challenger:
 def __init__(self,kind):
  if kind not in CATALOG:raise ValueError(kind)
  self.kind=kind;self.n=0;self.count=[0,0];self.mean=[[0.]*8 for _ in range(2)];self.m2=[[0.]*8 for _ in range(2)]
  self.ones=[[0]*8 for _ in range(2)];self.hist=[[[0]*8 for _ in range(8)] for _ in range(2)]
  self.splits=[[[[0,0] for side in range(2)] for t in range(7)] for f in range(8)] if kind=='stump' else []
  rng=random.Random(816);self.freq=[[rng.gauss(0,1) for _ in range(8)] for _ in range(24)] if kind=='fourier' else [];self.phase=[rng.uniform(0,2*math.pi) for _ in self.freq]
  dim=25 if kind=='fourier' else 9
  self.w=[0.]*dim;self.g2=[0.]*dim;self.z=[0.]*dim;self.best_split=None
 def vector(self,x):
  if self.kind=='fourier':return [1.]+[math.sqrt(2/24)*math.cos(sum(a*b for a,b in zip(freq,x))+phase) for freq,phase in zip(self.freq,self.phase)]
  return [1.]+list(x)
 def predict(self,x):
  valid(x)
  if self.n<30 or min(self.count)<5:return None
  k=self.kind
  if k in ('gaussian_nb','bernoulli_nb','histogram_nb'):
   scores=[]
   for y in (0,1):
    score=math.log((self.count[y]+1)/(self.n+2))
    for j,v in enumerate(x):
     if k=='gaussian_nb':
      var=max(.001,self.m2[y][j]/max(1,self.count[y]));score-=.5*(math.log(2*math.pi*var)+(v-self.mean[y][j])**2/var)
     elif k=='bernoulli_nb':
      p=(self.ones[y][j]+1)/(self.count[y]+2);score+=math.log(p if v>.5 else 1-p)
     else:score+=math.log((self.hist[y][j][bucket(v)]+1)/(self.count[y]+8))
    scores.append(score)
   return sigmoid(scores[1]-scores[0])
  if k=='centroid':
   d=[sum((v-m)**2 for v,m in zip(x,row))/8 for row in self.mean];return sigmoid(d[0]-d[1])
  if k=='stump':
   if self.best_split is None:return None
   j,t=self.best_split;counts=self.splits[j][t][int(x[j]>(t-3)*.5)]
   return (counts[1]+1)/(sum(counts)+2)
  return sigmoid(sum(w*v for w,v in zip(self.w,self.vector(x))))
 def update(self,x,y):
  valid(x)
  if y not in (0,1):raise ValueError('Label muss 0 oder 1 sein')
  k=self.kind;v=self.vector(x);margin=sum(a*b for a,b in zip(self.w,v));signed=2*y-1
  if k in ('adagrad','fourier'):
   err=sigmoid(margin)-y
   for i,a in enumerate(v):
    g=err*a+.001*self.w[i];self.g2[i]+=g*g;self.w[i]-=.1*g/math.sqrt(self.g2[i]+1e-8)
  elif k=='perceptron' and signed*margin<=0:
   for i,a in enumerate(v):self.w[i]+=.05*signed*a
  elif k=='passive_aggressive':
   step=min(.1,max(0,1-signed*margin)/(sum(a*a for a in v)+1e-8))
   for i,a in enumerate(v):self.w[i]+=step*signed*a
  elif k=='ftrl':
   err=sigmoid(margin)-y
   for i,a in enumerate(v):
    g=err*a;previous=self.g2[i];self.g2[i]+=g*g
    self.z[i]+=g-(math.sqrt(self.g2[i])-math.sqrt(previous))/.1*self.w[i]
    z=self.z[i];self.w[i]=0. if abs(z)<=.01 else -(z-math.copysign(.01,z))/((1+math.sqrt(self.g2[i]))/.1+.01)
  self.n+=1;self.count[y]+=1
  for j,a in enumerate(x):
   if k in ('gaussian_nb','centroid'):
    delta=a-self.mean[y][j];self.mean[y][j]+=delta/self.count[y];self.m2[y][j]+=delta*(a-self.mean[y][j])
   elif k=='bernoulli_nb':self.ones[y][j]+=int(a>.5)
   elif k=='histogram_nb':self.hist[y][j][bucket(a)]+=1
   if k=='stump':
    for t in range(7):self.splits[j][t][int(a>(t-3)*.5)][y]+=1
  if k=='stump':
   best=None
   for j,splits in enumerate(self.splits):
    for t,sides in enumerate(splits):
     if min(map(sum,sides))<10:continue
     impurity=sum(sum(side)*(1-sum((n/sum(side))**2 for n in side)) for side in sides)/self.n
     if best is None or impurity<best[0]:best=(impurity,j,t)
   self.best_split=(best[1],best[2]) if best else None

class Council:
 def __init__(self):
  self.models={key:Challenger(key) for key in CATALOG};self.evaluations={key:deque(maxlen=200) for key in CATALOG};self._cached=None
 def predictions(self,x):return {key:model.predict(x) for key,model in self.models.items()}
 def evaluate(self,predictions,baseline,y):
  if y not in (0,1) or not math.isfinite(baseline) or not 0<=baseline<=1:raise ValueError('Ungültige Prüfung')
  for key,p in predictions.items():
   if key not in self.models or p is None:continue
   if not math.isfinite(p) or not 0<=p<=1:raise ValueError('Ungültige eingefrorene Prognose')
   self.evaluations[key].append((p,baseline,y))
  self._cached=None
 def update(self,x,y):
  for model in self.models.values():model.update(x,y)
  self._cached=None
 def report(self):
  if self._cached is not None:return self._cached
  rows=[]
  for key,m in self.models.items():
   ev=list(self.evaluations[key]);n=len(ev)
   gain=[(b-y)**2-(p-y)**2 for p,b,y in ev];mean=sum(gain)/n if n else None
   se=math.sqrt(sum((g-mean)**2 for g in gain)/(n-1)/n) if n>1 else None
   lower=mean-3*se if se is not None else None
   recent=sum(gain[-20:])/20 if n>=20 else None
   ready=m.n>=100 and n>=80 and lower is not None and lower>.01 and recent>.01
   rows.append({'id':key,'name':CATALOG[key][0],'description':CATALOG[key][1],'trained':m.n,'validation':n,
    'brier':sum((p-y)**2 for p,b,y in ev)/n if n else None,'baseline_brier':sum((b-y)**2 for p,b,y in ev)/n if n else None,
    'gain':mean,'conservative_gain':lower,'recent_gain':recent,'qualified':ready,
    'state':'qualified' if ready else 'warming' if m.n<100 or n<80 else 'observing'})
  eligible=[r for r in rows if r['qualified']]
  champion=max(eligible,key=lambda r:r['conservative_gain'])['id'] if eligible else None
  for row in rows:row['selected']=row['id']==champion
  self._cached={'models':rows,'champion':champion,'new_models':10,'evaluation':'frozen_entry_event_replay','minimum_training':100,'minimum_validation':80}
  return self._cached
