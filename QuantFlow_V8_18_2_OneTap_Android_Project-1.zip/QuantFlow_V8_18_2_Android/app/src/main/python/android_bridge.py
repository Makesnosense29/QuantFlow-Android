"""Android lifecycle bridge for the unchanged V8.18.2-forward strategy."""
import os
import threading
import traceback
from pathlib import Path

_lock = threading.RLock()
_started = False
_bot_thread = None
_http_thread = None
_server = None
_data_dir = None


def _write_error(exc):
    try:
        p = Path(_data_dir or os.environ.get("HOME", ".")) / "android_python.log"
        with p.open("a", encoding="utf-8") as f:
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass


def start(data_dir):
    global _started, _bot_thread, _http_thread, _server, _data_dir
    with _lock:
        if _started:
            return "already-running"
        _data_dir = str(data_dir)
        os.environ["BOT_DATA_DIR"] = _data_dir
        os.environ["BOT_LOG_FILE"] = str(Path(_data_dir) / "bot.log")
        Path(_data_dir).mkdir(parents=True, exist_ok=True)
        try:
            import bot
            import mobile_app
            bot.STOP.clear()
            _server = mobile_app.ThreadingHTTPServer(("127.0.0.1", 8766), mobile_app.H)
            _http_thread = threading.Thread(target=_server.serve_forever, name="quantflow-dashboard", daemon=True)
            _http_thread.start()
            _bot_thread = threading.Thread(target=bot.main, name="quantflow-bot", daemon=True)
            _bot_thread.start()
            _started = True
            return "started"
        except Exception as exc:
            _write_error(exc)
            try:
                if _server:
                    _server.server_close()
            except Exception:
                pass
            _server = None
            raise


def stop():
    global _started, _server
    with _lock:
        if not _started:
            return "not-running"
        try:
            import bot
            bot.STOP.set()
        except Exception:
            pass
        try:
            if _server:
                _server.shutdown()
                _server.server_close()
        except Exception as exc:
            _write_error(exc)
        _server = None
        _started = False
        return "stopping"


def status():
    return {
        "started": bool(_started),
        "bot_alive": bool(_bot_thread and _bot_thread.is_alive()),
        "dashboard_alive": bool(_http_thread and _http_thread.is_alive()),
        "data_dir": _data_dir,
    }
