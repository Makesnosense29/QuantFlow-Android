"""Bounded local statistical experts; only completed trades become examples."""
import math
from collections import deque

class Experts:
 def __init__(self):self.examples=deque(maxlen=512)
 def update(self,x,label):self.examples.append((tuple(x),int(label)))
 def assess(self,x,logistic):
  if len(x)!=8 or not all(math.isfinite(v) for v in x):raise ValueError('Ungültige Modellmerkmale')
  distances=sorted(((sum((a-b)**2 for a,b in zip(x,row))/len(x),y) for row,y in self.examples),key=lambda item:item[0])
  nearby=distances[:15]
  # Equal neighbour votes and Beta(1,1) smoothing avoid singular weights.
  knn=(1+sum(y for _,y in nearby))/(2+len(nearby)) if len(nearby)>=15 else None
  def regime(row):return (row[4]>=1,row[5]>=.6)
  cohort=[y for row,y in self.examples if regime(row)==regime(x)]
  momentum=(1+sum(cohort))/(2+len(cohort)) if len(cohort)>=20 else None
  scores={'logistic':logistic,'neighbours':knn,'momentum':momentum}
  active=[v for v in scores.values() if v is not None]
  disagreement=max(active)-min(active)
  novel=len(self.examples)>=50 and distances[0][0]>.5
  abstain=novel or disagreement>.35
  return {'score':sum(active)/len(active),'experts':scores,'examples':len(self.examples),
   'disagreement':disagreement,'novel':novel,'abstain':abstain,
   'reason':'Ungewohnte Merkmale' if novel else 'Modelle widersprechen sich' if abstain else 'Bewertung verfügbar'}
