"""Read-only OHLCV charts. No connection to order decisions or trading state."""
import json, math, re, threading, time
from urllib.request import Request, urlopen
from urllib.parse import urlencode
NETWORKS={'solana':'solana','ethereum':'eth','base':'base','bsc':'bsc','arbitrum':'arbitrum','polygon':'polygon_pos','avalanche':'avax','optimism':'optimism'}
LOCK=threading.Lock()
CACHE={}
LAST_FETCH=0.0
FRAMES={'1m':('minute',1),'5m':('minute',5),'15m':('minute',15),'1h':('hour',1)}

def clean_rows(rows):
    if not isinstance(rows,list):raise ValueError('Keine Kerzendaten')
    result={}
    for row in rows:
        if not isinstance(row,list) or len(row)!=6:raise ValueError('Ungültiges Kerzenformat')
        t,o,h,l,c,v=map(float,row)
        if not all(math.isfinite(x) for x in (t,o,h,l,c,v)) or t<=0 or min(o,h,l,c)<=0 or v<0 or h<max(o,c,l) or l>min(o,c):raise ValueError('Ungültige Kurswerte')
        result[int(t)]=[int(t),o,h,l,c,v]
    return [result[k] for k in sorted(result)][-120:]

def chart(chain,pool,token,frame):
    global LAST_FETCH
    if chain not in NETWORKS or frame not in FRAMES or not all(re.fullmatch(r'[A-Za-z0-9]{20,100}',x or '') for x in (pool,token)):
        return {'error':'Blockchain, Pool oder Token-Adresse ungültig','rows':[]}
    key=(chain,pool,token,frame)
    with LOCK:
        now=time.time();old=CACHE.get(key)
        if old and now-old['fetched_at']<30:return old
        if now-LAST_FETCH<30:
            return {**(old or {'rows':[]}), 'stale':True,'retry_after':math.ceil(30-(now-LAST_FETCH)), 'error':'Abfragelimit: bitte kurz warten'}
        LAST_FETCH=now
        kind,aggregate=FRAMES[frame]
        query=urlencode({'aggregate':aggregate,'limit':120,'currency':'usd','token':token,'include_empty_intervals':'false'})
        url=f'https://api.geckoterminal.com/api/v2/networks/{NETWORKS[chain]}/pools/{pool}/ohlcv/{kind}?{query}'
        try:
            with urlopen(Request(url,headers={'Accept':'application/json','User-Agent':'NeonOrbitDashboard/8.9'}),timeout=8) as r:data=json.load(r)
            rows=clean_rows(data['data']['attributes']['ohlcv_list'])
            # Refuse ambiguous token orientation, even if the provider accepted the request.
            addresses=[str(data.get('meta',{}).get(side,{}).get('address','')) for side in ('base','quote')]
            norm=(lambda x:x) if chain=='solana' else (lambda x:x.lower())
            if norm(token) not in [norm(x) for x in addresses]:raise ValueError('Token-Zuordnung nicht bestätigt')
            result={'rows':rows,'fetched_at':time.time(),'source':'GeckoTerminal','frame':frame,'currency':'USD','chain':chain,'pool':pool,'token':token,'stale':False}
            if not rows:result['error']='Für diesen Pool sind keine Kerzen verfügbar'
            if len(CACHE)>=32:CACHE.pop(next(iter(CACHE)))
            CACHE[key]=result
            return result
        except Exception as exc:
            return {**(old or {'rows':[]}), 'error':'Kerzenquelle nicht verfügbar: '+type(exc).__name__,'stale':True,'retry_after':30}
