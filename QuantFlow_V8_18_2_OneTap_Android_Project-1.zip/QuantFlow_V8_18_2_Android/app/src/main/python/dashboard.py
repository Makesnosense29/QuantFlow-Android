"""Minimal throttled console dashboard; mobile_app.py serves the mobile UI."""
import time

_LAST_PRINT = 0.0
_LAST_STATE = None


def render(state, snapshot):
    """Print a compact status line without flooding parallel_runtime.log."""
    global _LAST_PRINT, _LAST_STATE
    now = time.monotonic()
    cfg = snapshot.get("config") or {}
    interval = max(1.0, float(cfg.get("console_status_interval_seconds", 30)))
    signature = (
        snapshot.get("status", ""),
        len(state.get("positions", {})),
        bool(snapshot.get("daily_halt")),
        bool(snapshot.get("drawdown_halt")),
    )
    if _LAST_STATE == signature and now - _LAST_PRINT < interval:
        return
    print(
        f"{snapshot.get('time', '')} | {snapshot.get('status', '')} | "
        f"Portfolio {snapshot.get('portfolio_value', 0):.2f} EUR | "
        f"Offene Positionen {len(state.get('positions', {}))}",
        flush=True,
    )
    _LAST_PRINT = now
    _LAST_STATE = signature
