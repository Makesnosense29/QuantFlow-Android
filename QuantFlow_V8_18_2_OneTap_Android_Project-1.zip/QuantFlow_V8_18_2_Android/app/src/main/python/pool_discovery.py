"""Public GeckoTerminal pool discovery; addresses only, never execution quotes."""
from urllib.request import Request,urlopen
import json
from urllib.error import HTTPError
import time

NETWORKS={'solana':'solana','ethereum':'eth','base':'base','bsc':'bsc','arbitrum':'arbitrum',
          'polygon':'polygon_pos','avalanche':'avax','optimism':'optimism'}


def addresses(data,network):
    if not isinstance(data,dict) or not isinstance(data.get('data'),list):
        raise ValueError('Ungültige Pool-Antwort')
    included={x.get('id'):x.get('attributes',{}) for x in data.get('included',[]) if isinstance(x,dict) and x.get('type')=='token'}
    found=set()
    for pool in data['data']:
        if not isinstance(pool,dict):continue
        for side in ('base_token','quote_token'):
            ref=((pool.get('relationships') or {}).get(side) or {}).get('data') or {}
            ident=str(ref.get('id',''))
            if not ident.startswith(network+'_'):continue
            address=included.get(ident,{}).get('address') or ident[len(network)+1:]
            if isinstance(address,str) and address and '/' not in address and len(address)<150:found.add(address)
    return found


def request_page(url):
    # One attempt only; scheduling/backoff belongs to the crawler.
    req=Request(url,headers={'User-Agent':'MultiChainPaperBot/8.7','Accept':'application/json'})
    with urlopen(req,timeout=8) as response:return json.load(response)


class PoolCrawler:
    def __init__(self,cursor=0):self.cursor=cursor;self.pages=0;self.error=None
    def step(self,chains,pages,fetch=request_page):
        chain=chains[self.cursor%len(chains)]
        group=self.cursor//len(chains)
        page=(group//2)%pages+1
        kind=('pools','new_pools')[group%2]
        network=NETWORKS[chain]
        url=f'https://api.geckoterminal.com/api/v2/networks/{network}/{kind}?page={page}&include=base_token,quote_token'
        data=fetch(url)
        tokens=addresses(data,network)
        self.cursor+=1;self.pages+=1;self.error=None
        return chain,tokens
