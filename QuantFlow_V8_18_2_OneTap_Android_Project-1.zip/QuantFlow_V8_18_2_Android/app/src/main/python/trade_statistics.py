"""Descriptive closed-trade statistics, never a future return forecast."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import math
import re
from statistics import mean, median, stdev
from learning import Learner

READER=Learner(chain=None)


def wilson(wins,n):
    if not n:return None
    p=wins/n;z=1.959963984540054;d=1+z*z/n
    center=(p+z*z/(2*n))/d
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0,center-half),min(1,center+half)]


def summary(trades):
    pnl=[t['net_pnl'] for t in trades];n=len(pnl)
    wins=[x for x in pnl if x>0];losses=[-x for x in pnl if x<0]
    aw=mean(wins) if wins else None;al=mean(losses) if losses else None
    win_streak=loss_streak=max_w=max_l=0
    for x in pnl:
        win_streak=win_streak+1 if x>0 else 0
        loss_streak=loss_streak+1 if x<0 else 0
        max_w=max(max_w,win_streak);max_l=max(max_l,loss_streak)
    durations=[(t['closed_at']-t['opened_at'])/60 for t in trades]
    return {'closed':n,'wins':len(wins),'losses':len(losses),'flat':n-len(wins)-len(losses),
            'net_pnl':sum(pnl),'win_rate':len(wins)/n if n else None,'win_rate_wilson95':wilson(len(wins),n),
            'profit_factor':sum(wins)/sum(losses) if losses else None,
            'profit_factor_note':'keine Verluste: nicht bestimmbar' if not losses else '',
            'sum_winning_pnl':sum(wins),'sum_losing_pnl':-sum(losses),
            'expectancy_eur':mean(pnl) if n else None,'median_pnl':median(pnl) if n else None,
            'pnl_std_eur':stdev(pnl) if n>1 else None,'average_win':aw,'average_loss':al,
            'payoff_ratio':aw/al if aw is not None and al else None,
            'break_even_win_rate':al/(aw+al) if aw is not None and al is not None else None,
            'best_trade':max(pnl) if n else None,'worst_trade':min(pnl) if n else None,
            'longest_win_streak':max_w,'longest_loss_streak':max_l,
            'average_hold_minutes':mean(durations) if durations else None,
            'median_hold_minutes':median(durations) if durations else None,
            'estimated_costs_closed_eur':sum(t['costs_eur'] for t in trades),
            'average_return_pct':mean(t['net_pnl']/t['size']*100 for t in trades) if n and all(t['size']>0 for t in trades) else None}


def calculate(trades,initial):
    result=summary(trades);equity=peak=float(initial);dd_eur=dd_pct=0
    for t in trades:
        equity+=t['net_pnl'];peak=max(peak,equity)
        dd_eur=max(dd_eur,peak-equity)
        if peak>0:dd_pct=max(dd_pct,(peak-equity)/peak*100)
    result['closed_curve_drawdown_eur']=dd_eur;result['closed_curve_drawdown_pct']=dd_pct
    result['drawdown_note']='Nur kumulierte abgeschlossene Trade-Ergebnisse; offene Verluste und Zwischenkurse fehlen.'
    result['rolling']={str(k):summary(trades[-k:]) for k in (5,10,20)}
    axes={'chain':lambda t:t['chain'],'token':lambda t:t['key'],'exit':lambda t:t['exit_reason'],
          'entry_hour_utc':lambda t:str(datetime.fromtimestamp(t['opened_at'],timezone.utc).hour),
          'score':lambda t:(re.search(r'(?:^|;)score=([0-9.]+)',t['entry_reason']).group(1) if re.search(r'(?:^|;)score=([0-9.]+)',t['entry_reason']) else 'unknown'),
          'version':lambda t:(re.search(r'(?:^|;)version=([^;,]+)',t['entry_reason']).group(1) if re.search(r'(?:^|;)version=([^;,]+)',t['entry_reason']) else 'legacy_unbekannt')}
    result['breakdowns']={}
    for name,key in axes.items():
        groups=defaultdict(list)
        for t in trades:groups[key(t)].append(t)
        result['breakdowns'][name]={label:summary(items) for label,items in groups.items()}
    counts=Counter(t['key'] for t in trades)
    result['unique_tokens']=len(counts)
    result['largest_token_share']=max(counts.values())/len(trades) if trades else None
    result['unavailable']={'sharpe':'Keine regelmäßige vollständige Portfolio-Renditezeitreihe.',
        'sortino':'Keine regelmäßige vollständige Portfolio-Renditezeitreihe.',
        'calmar':'Kein vollständiger Portfolio-Drawdown und keine geeignete annualisierte Rendite.',
        'var_cvar':'Zu kleine/abhängige Stichprobe für belastbare Risikoschätzung.',
        'alpha_beta':'Keine zeitlich passende Benchmark-Zeitreihe.',
        'kelly':'Keine belastbare Treffer-/Auszahlungsverteilung; keine automatische Einsatzsteigerung.',
        'mae_mfe':'Keine durchgehenden Einzelpositions-Kurspfade für alle historischen Trades.'}
    return result


def read_statistics(path,initial):
    try:return calculate(READER.load(path).closed,initial)
    except Exception as exc:return {'error':str(exc),'closed':0}
