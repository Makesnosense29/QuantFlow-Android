"""Transparent rule-based context checks, alongside the separate learning model."""
import math
from statistics import median


def market_context(pair_map, selected, cfg, chain, now):
    values=[];fresh=0
    rules=cfg.get('chain_rules',{}).get(chain,cfg['chain_rules']['solana'])
    for pair in pair_map.values():
        try:
            age=now-float(pair['_received_epoch'])
            if age<0 or age>cfg['max_quote_age_seconds']:continue
            price=float(pair['priceUsd'])
            if not math.isfinite(price) or price<=0:continue
            fresh+=1
            liquidity=float(pair['liquidity']['usd']);change=float(pair['priceChange']['m5'])
            if not math.isfinite(liquidity) or not math.isfinite(change):continue
            if liquidity<rules['min_liquidity_usd']:continue
            values.append(change)
        except (KeyError,ValueError,TypeError):continue
    coverage=fresh/selected if selected else 0
    result={'sample':len(values),'selected':selected,'fresh_quotes':fresh,'coverage':coverage,
            'median_m5':median(values) if values else None,
            'negative_share':sum(v<0 for v in values)/len(values) if values else None,
            'blocked':False,'state':'insufficient'}
    if selected>=cfg['context_min_sample'] and coverage<cfg['context_min_quote_coverage']:
        result.update(blocked=True,state='data_gap')
    elif len(values)>=cfg['context_min_sample']:
        weak=result['median_m5']<=cfg['context_weak_median_m5_pct'] and result['negative_share']>=cfg['context_negative_share']
        result.update(blocked=weak,state='weak' if weak else 'normal')
    return result


def loss_pauses(closed, cfg, now):
    groups={}
    for item in closed:
        if not math.isfinite(item['closed_at']) or item['closed_at']>now+60:
            raise ValueError('Trade-Abschluss liegt in der Zukunft')
        if item['closed_at']>=now-cfg['loss_memory_hours']*3600:
            groups.setdefault(item['key'],[]).append(item)
    pauses={}
    n=cfg['loss_pause_count']
    for key,items in groups.items():
        items=sorted(items,key=lambda x:x['closed_at'])[-n:]
        if len(items)==n and all(x['net_pnl']<0 for x in items):
            until=items[-1]['closed_at']+cfg['loss_pause_hours']*3600
            if until>now:pauses[key]=until
    return pauses
