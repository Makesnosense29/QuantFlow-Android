"""Read-only local diagnostics; no network, reset, deletion or trading."""
import json,sqlite3,time
from pathlib import Path

def report(root):
 root=Path(root);checks=[]
 for name,required in [('config.json',True),('state.json',True),('scanner_snapshot.json',False)]:
  try:
   data=json.loads((root/name).read_text())
   if not isinstance(data,dict):raise ValueError('Kein JSON-Objekt')
   detail={}
   if name=='config.json':detail={k:data.get(k) for k in ('version','mode','scan_interval_seconds','max_new_positions_per_scan','max_trades_per_day')}
   if name=='state.json':
    if 'cash_eur' not in data or not isinstance(data.get('positions'),dict):raise ValueError('Ungültiges State-Schema')
    detail={'open_positions':len(data['positions']),'daily_halt':data.get('daily_halt',False),'drawdown_halt':data.get('drawdown_halt',False)}
   if name=='scanner_snapshot.json':detail={'heartbeat_age_seconds':time.time()-data['heartbeat_epoch'] if data.get('heartbeat_epoch') else None,'scan_running':data.get('scan_running',False),'scan_elapsed_seconds':data.get('scan_elapsed_seconds',0),'laboratory':data.get('strategy_database',{}).get('mode')}
   checks.append({'file':name,'status':'ok','detail':detail})
  except Exception as e:checks.append({'file':name,'status':'error' if required else 'warning','error':str(e)})
 for name in ('strategies.sqlite3','backtests.sqlite3'):
  p=root/name
  if not p.exists():checks.append({'file':name,'status':'not_created'});continue
  try:
   c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True,timeout=1)
   try:result=c.execute('PRAGMA quick_check').fetchone()[0]
   finally:c.close()
   checks.append({'file':name,'status':'ok' if result=='ok' else 'warning','detail':result})
  except Exception as e:checks.append({'file':name,'status':'warning','error':str(e)})
 running=None
 try:
  import fcntl
  with (root/'.paper_bot.lock').open('r') as f:
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);running=False
   except BlockingIOError:running=True
 except (OSError,ImportError):pass
 return {'time':time.time(),'bot_lock_held':running,'checks':checks,'note':'Nur Diagnose; keine Daten verändert. Lange Scans sind von einem abgestürzten Prozess zu unterscheiden.'}

if __name__=='__main__':print(json.dumps(report(Path(__file__).parent),indent=2,ensure_ascii=False))
