"""Idempotent paper funding migration; never creates trading profits."""
import copy,math
from datetime import datetime,timezone

def migrate(config,state):
 c=copy.deepcopy(config);s=copy.deepcopy(state)
 old=float(c['initial_capital_eur'])
 if not math.isfinite(old) or old<=0:raise ValueError('Ungültiges bisheriges Startkapital')
 for k in ('cash_eur',):
  if not math.isfinite(float(s[k])):raise ValueError('Ungültiger Kontostand')
 delta=max(0.,10000.-old)
 if delta:
  equity=float(s['cash_eur']);rate=(float(c['paper_fee_pct'])+float(c['paper_slippage_pct']))/100
  for pos in s.get('positions',{}).values():
   entry=float(pos['entry_price'])
   if entry<=0:raise ValueError('Ungültiger Einstiegskurs')
   equity+=float(pos['invested_eur'])*float(pos.get('remaining_fraction',1))*float(pos.get('current_price') or entry)/entry*(1-rate)
  for k in ('day_start_equity_eur','peak_equity_eur'):
   value=float(s.get(k,equity))
   if not math.isfinite(value):raise ValueError('Ungültiger Risikostand')
   s[k]=value+delta
  s['cash_eur']=float(s['cash_eur'])+delta
  s.setdefault('capital_events',[]).append({'type':'PAPER_DEPOSIT','time':datetime.now(timezone.utc).isoformat(),'amount_eur':delta,'previous_capital_eur':old,'capital_eur':10000.,'reason':'V8.14 Kapitalerhöhung; kein Handelsgewinn'})
  for k in ('max_daily_loss_eur','position_size_eur'):c[k]=float(c[k])*10000./old
  c['initial_capital_eur']=10000.
 c['max_open_positions']=max(10,int(c['max_open_positions']))
 c['spread_risk_across_slots']=True
 return c,s,delta
