"""Explicit experimental momentum profiles; no profitability estimate."""
import math
DEFAULTS={'high_momentum_enabled':True,'high_trigger_h1_pct':25.,'high_trigger_m5_pct':4.,
 'high_max_h1_pct':60.,'high_max_m5_pct':8.,'high_min_liquidity_usd':250000.,
 'high_min_volume_h1_usd':100000.,'high_min_h1_buys':80,'high_min_m5_buys':8,
 'high_min_buy_sell_ratio':1.3,'high_stop_loss_pct':-10.,'high_gap_buffer_pct':8.,
 'high_confirmation_max_move_pct':4.,'high_max_hold_minutes':120.,
 'min_net_reward_risk_tp1':1.2,'min_net_reward_risk_tp2':2.2,'entry_recheck_max_move_pct':1.5}
EXIT_KEYS=('stop_loss_pct','gap_buffer_pct','take_profit_1_pct','take_profit_2_pct',
 'trailing_stop_pct','tp1_sell_fraction','tp2_sell_fraction','post_tp1_protect_pct',
 'stale_exit_minutes','stale_exit_max_return_pct','stale_exit_max_net_return_pct','absolute_max_hold_minutes')

FAST_DEFAULTS={'entries_per_minute':2,'quick_take_net_pct':1.0,'quick_take_fraction':0.25,'protect_arm_net_pct':0.8,'protect_floor_net_pct':0.25,'protect_giveback_net_pct':0.35}

def fast_settings(cfg):return {**FAST_DEFAULTS,**cfg.get('fast_v812',{})}

def settings(cfg):return {**DEFAULTS,**cfg.get('strategy_v811',{})}
def high(p,cfg):
 x=p.get('priceChange') or {};s=settings(cfg)
 return s['high_momentum_enabled'] and (float(x.get('h1',0))>=s['high_trigger_h1_pct'] or float(x.get('m5',0))>=s['high_trigger_m5_pct'])

def rules_for(p,base,cfg):
 r=dict(base);s=settings(cfg)
 if high(p,cfg):
  for k,v in {'min_liquidity_usd':s['high_min_liquidity_usd'],'min_volume_h1_usd':s['high_min_volume_h1_usd'],
   'min_h1_buys':s['high_min_h1_buys'],'min_buy_sell_ratio':s['high_min_buy_sell_ratio'],'min_m5_price_change_pct':1.,'min_score':9}.items():r[k]=max(r.get(k,v),v)
  r['max_h1_price_change_pct']=s['high_max_h1_pct'];r['max_m5_price_change_pct']=s['high_max_m5_pct']
  r.update(score_h1_ideal_min=10.,score_h1_ideal_max=45.,score_m5_ideal_min=1.,score_m5_ideal_max=6.)
 return r

def recent_flow_ok(p,cfg):
 if not high(p,cfg):return True
 try:
  tx=p['txns']['m5'];b=float(tx['buys']);s=float(tx['sells']);v=float(p['volume']['m5'])
  return all(math.isfinite(x) and x>=0 for x in (b,s,v)) and v>0 and b>=settings(cfg)['high_min_m5_buys'] and b/max(s,1)>=settings(cfg)['high_min_buy_sell_ratio']
 except (KeyError,ValueError,TypeError):return False

def make_plan(p,cfg,rate):
 s=settings(cfg);plan={k:cfg[k] for k in EXIT_KEYS};plan['profile']='standard'
 if high(p,cfg):
  plan.update(profile='high_momentum',stop_loss_pct=s['high_stop_loss_pct'],gap_buffer_pct=max(cfg['gap_buffer_pct'],s['high_gap_buffer_pct']),absolute_max_hold_minutes=min(cfg['absolute_max_hold_minutes'],s['high_max_hold_minutes']))
 # Both entry and exit costs: target is an exit level, NOT an expected return.
 retained=(1-rate)**2
 loss=1-retained*(1+plan['stop_loss_pct']/100)
 for key,r in [('take_profit_1_pct',s['min_net_reward_risk_tp1']),('take_profit_2_pct',s['min_net_reward_risk_tp2'])]:
  plan[key]=max(plan[key],100*((1+r*loss)/retained-1))
 plan['profit_guard']=fast_settings(cfg)
 plan['net_rr_tp1']=(retained*(1+plan['take_profit_1_pct']/100)-1)/loss
 plan['net_rr_tp2']=(retained*(1+plan['take_profit_2_pct']/100)-1)/loss
 return plan

def stress_loss(plan,rate):return 1-(1-rate)**2*(1+(plan['stop_loss_pct']-plan['gap_buffer_pct'])/100)

def allocation(state,cfg,equity,plan,rate):
 reserved=0.;exposure=0.
 for p in state.get('positions',{}).values():
  principal=float(p['invested_eur'])*float(p['remaining_fraction']);exposure+=principal
  old=p.get('exit_plan',cfg);stress=max(0,1+(old['stop_loss_pct']-old['gap_buffer_pct'])/100)
  marked=principal*float(p.get('current_price') or p['entry_price'])/float(p['entry_price'])*(1-rate)
  reserved+=max(0,marked-principal*stress*(1-rate))
 day_loss=max(0,float(state.get('day_start_equity_eur',equity))-equity)
 available=max(0,float(cfg['max_daily_loss_eur'])-day_loss-reserved)
 slots=max(1,int(cfg['max_open_positions'])-len(state.get('positions',{})))
 share=available/slots if cfg.get('spread_risk_across_slots',False) else available
 risk_budget=min(equity*cfg['risk_per_trade_pct']/100,share)
 size=max(0,min(cfg['position_size_eur'],state['cash_eur'],equity*cfg['max_exposure_pct']/100-exposure,risk_budget/stress_loss(plan,rate)))
 return {'gross_eur':size,'remaining_risk_eur':available,'reserved_risk_eur':reserved,'stress_loss_eur':size*stress_loss(plan,rate)}

def validate(cfg):
 f=fast_settings(cfg)
 if not isinstance(f['entries_per_minute'],int) or isinstance(f['entries_per_minute'],bool) or not 1<=f['entries_per_minute']<=2:raise ValueError('Maximal zwei Einstiege je rollender Minute')
 for k,v in f.items():
  if not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or v<=0:raise ValueError('Ungültiger Schnellmodus: '+k)
 if not f['protect_floor_net_pct']<f['protect_arm_net_pct']<=f['quick_take_net_pct'] or f['protect_giveback_net_pct']>=f['protect_arm_net_pct'] or not 0<f['quick_take_fraction']<1:raise ValueError('Gewinnschutz-Min/Max ungültig')
 s=settings(cfg)
 if not isinstance(s['high_momentum_enabled'],bool):raise ValueError('Profil-Schalter muss bool sein')
 for k,v in s.items():
  if k!='high_momentum_enabled' and (not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v)):raise ValueError('Ungültige Strategiezahl: '+k)
 for k in DEFAULTS:
  if k not in ('high_momentum_enabled','high_stop_loss_pct') and s[k]<=0:raise ValueError('Strategiewert muss positiv sein: '+k)
 if not -30<=s['high_stop_loss_pct']<0 or s['high_gap_buffer_pct']>=100+s['high_stop_loss_pct']:raise ValueError('High-Momentum-Stop/Gap ungültig')
 if not 0<s['high_trigger_h1_pct']<=s['high_max_h1_pct']<=100 or not 0<s['high_trigger_m5_pct']<=s['high_max_m5_pct']<=20:raise ValueError('Momentum-Min/Max ungültig')
 if not 1<=s['min_net_reward_risk_tp1']<s['min_net_reward_risk_tp2']:raise ValueError('Nettoziel-Verhältnis ungültig')
 if not 0<cfg['min_position_size_eur']<=cfg['position_size_eur']:raise ValueError('Einsatz-Min/Max ungültig')
 if not 0<cfg['risk_per_trade_pct']<=100 or not 0<cfg['max_exposure_pct']<=100:raise ValueError('Risiko/Exposure ungültig')
 if not 0<cfg['take_profit_1_pct']<cfg['take_profit_2_pct']:raise ValueError('TP1/TP2 ungültig')
 if cfg['stop_loss_pct']-cfg['gap_buffer_pct']<=-100:raise ValueError('Stop/Gap ungültig')
 if not math.isfinite(float(cfg.get('stale_exit_max_net_return_pct',0))):raise ValueError('Netto-Zeitexit ungültig')
 for rules in cfg.get('chain_rules',{}).values():
  if 'max_buy_sell_ratio' in rules and (not math.isfinite(float(rules['max_buy_sell_ratio'])) or float(rules['max_buy_sell_ratio'])<=float(rules.get('min_buy_sell_ratio',0))):raise ValueError('Buy/Sell-Maximum ungültig')
  for lo,hi in [('min_h1_price_change_pct','max_h1_price_change_pct'),('min_m5_price_change_pct','max_m5_price_change_pct')]:
   if lo in rules and hi in rules and not (math.isfinite(rules[lo]) and math.isfinite(rules[hi]) and rules[lo]<=rules[hi]):raise ValueError('Chain-Min/Max ungültig')
