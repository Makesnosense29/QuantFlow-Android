"""Offline replay of one catalogue variant, with persistent runs and no run quota.
Sampled-quote research model, not TradingView's tester or the full trading engine.
"""
import argparse,hashlib,json,math,sqlite3,time,uuid
from contextlib import closing
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).resolve().parent

def replay(path,params,rate):
 positions={};confirm={};trades=[];previous=0;frames=0;invalid=0
 with Path(path).open() as f:
  for line in f:
   try:event=json.loads(line)
   except json.JSONDecodeError:invalid+=1;continue
   if event.get('kind')!='candidate_scan':continue
   stamp=datetime.fromisoformat(event['time'].replace('Z','+00:00'))
   if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
   now=stamp.timestamp()
   if now<previous:raise ValueError('Aufzeichnungen nicht chronologisch sortiert')
   previous=now;frames+=1;chain=event['chain'];seen=set()
   for token,p in event.get('pairs',{}).items():
    key=(chain,token);seen.add(key)
    try:
     price=float(p['priceUsd']);h1=float(p['priceChange']['h1']);m5=float(p['priceChange']['m5']);liq=float(p['liquidity']['usd']);vol=float(p['volume']['h1']);pool=p['pairAddress']
     if not all(math.isfinite(x) for x in (price,h1,m5,liq,vol)) or price<=0:raise ValueError()
    except (KeyError,ValueError,TypeError):invalid+=1;confirm.pop(key,None);continue
    if key in positions:
     pos=positions[key]
     if pool!=pos['pair']:continue
     move=(price/pos['entry']-1)*100
     reason='STOP' if move<=-params['stop_pct'] else 'TARGET' if move>=pos['target'] else 'TIME' if now-pos['opened']>=7200 else None
     pos.update(last_price=price,last_time=now)
     if reason:
      trades.append({'chain':chain,'token':token,'pair':pool,'opened':pos['opened'],'closed':now,'net_return_pct':((1-rate)**2*price/pos['entry']-1)*100,'reason':reason})
      del positions[key];confirm.pop(key,None)
     continue
    qualified=liq>=params['min_liquidity'] and vol>=params['min_volume_h1'] and 1<=h1<=params['max_h1'] and 0<=m5<=params['max_m5']
    if not qualified:confirm.pop(key,None);continue
    old=confirm.get(key);move=(price/old['price']-1)*100 if old else 0
    n=old['n']+1 if old and old['pool']==pool and now>old['time'] and now-old['time']<=180 and -.5<=move<=3 else 1
    confirm[key]={'n':n,'pool':pool,'time':now,'price':price}
    if n>=3:
     retained=(1-rate)**2;loss=1-retained*(1-params['stop_pct']/100)
     positions[key]={'entry':price,'opened':now,'pair':pool,'target':100*((1+params['net_reward_risk']*loss)/retained-1),'last_price':price,'last_time':now}
   for key in list(confirm):
    if key[0]==chain and key not in seen:confirm.pop(key,None)
 if not frames:raise ValueError('Keine candidate_scan-Aufzeichnungen vorhanden')
 vals=[x['net_return_pct'] for x in trades]
 return {'model':'catalogue sampled-quote replay v1','frames':frames,'invalid_records':invalid,'closed':len(vals),'open_unvalued':len(positions),'mean_net_return_pct':sum(vals)/len(vals) if vals else None,'trades':trades,'note':'Keine Portfolio-Rendite. Fehlende Intrabar-Kurse, Gas und Hauptstrategie-Teilverkäufe nicht modelliert.'}

def archive(path,result):
 with closing(sqlite3.connect(path)) as c:
  with c:
   c.execute('CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,created REAL,result TEXT NOT NULL)')
   ident=uuid.uuid4().hex;c.execute('INSERT INTO runs VALUES (?,?,?)',(ident,time.time(),json.dumps(result,allow_nan=False)))
 return ident

def _summary(path):
 if not Path(path).exists():return {'runs':0,'recent':[]}
 with closing(sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)) as c:
  return {'runs':c.execute('SELECT COUNT(*) FROM runs').fetchone()[0],'recent':[{'id':row[0],**{k:v for k,v in json.loads(row[1]).items() if k not in ('trades','parameters')}} for row in c.execute('SELECT id,result FROM runs ORDER BY created DESC LIMIT 5')]}

def summary(path):
 try:return _summary(path)
 except (sqlite3.Error,ValueError,TypeError) as exc:return {'runs':None,'recent':[],'error':type(exc).__name__}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--observations',type=Path,default=BASE/'observations.jsonl');p.add_argument('--variant',type=int,default=1);p.add_argument('--archive',type=Path,default=BASE/'backtests.sqlite3');a=p.parse_args()
 try:
  with closing(sqlite3.connect((BASE/'strategies.sqlite3').as_uri()+'?mode=ro',uri=True)) as c:row=c.execute('SELECT parameters FROM variants WHERE id=?',(a.variant,)).fetchone()
  if not row:raise ValueError('Varianten-ID ist nicht im aktuellen Katalog vorhanden')
  params=json.loads(row[0]);cfg=json.loads((BASE/'config.json').read_text());rate=(cfg['paper_slippage_pct']+cfg['paper_fee_pct'])/100
  if not 0<=rate<1:raise ValueError("Ungültige Kosten")
  # Freeze the source for reproducibility; never read a moving log during replay.
  import tempfile,shutil
  with tempfile.TemporaryDirectory() as tmp:
   source=Path(tmp)/'observations.jsonl';shutil.copyfile(a.observations,source);digest=hashlib.sha256(source.read_bytes()).hexdigest();result=replay(source,params,rate)
  result.update(variant=a.variant,parameters=params,cost_per_side=rate,source_sha256=digest,source_name=a.observations.name,code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
  ident=archive(a.archive,result);print(json.dumps({'run_id':ident,**{k:v for k,v in result.items() if k!='trades'}},indent=2,ensure_ascii=False))
 except Exception as exc:p.exit(1,str(exc)+'\n')
