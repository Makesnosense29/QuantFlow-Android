"""Local online logistic regression; labels become available only on full exit.

Predictions for evaluation are frozen at BUY, before any later SELL is observed.
This is an experimental ranking aid, not a calibrated probability or profit promise.
"""
import csv
from experts import Experts
from council import Council
from datetime import datetime, timezone
import math
import re
from chains import trade_chain, normalize

FEATURES = ('score','liquidity','volume','ratio','h1','m5','age','turnover')


def features(score, reason):
    def get(name):
        match = re.search(r'(?:^|[;,])'+re.escape(name)+r'=([-+0-9.eE]+)', reason)
        if not match:
            raise ValueError('Fehlendes Entry-Merkmal: '+name)
        v = float(match.group(1))
        if not math.isfinite(v):
            raise ValueError('Nicht endliches Merkmal')
        return v
    def clip(v): return max(-2.0, min(2.0, v))
    return [clip(float(score)/10), clip(math.log1p(max(0,get('liq')))/14),
            clip(math.log1p(max(0,get('vol1h')))/14), clip(math.log1p(max(0,get('ratio')))),
            clip(get('chg1h')/30), clip(get('m5')/5),
            clip(math.log1p(max(0,get('age')))/12), clip(get('turn')/8)]


def sigmoid(z):
    return 1/(1+math.exp(-max(-30, min(30,z))))


class Model:
    def __init__(self):
        self.experts=Experts()
        self.council=Council()
        self.weights=[0.0]*(len(FEATURES)+1)
        self.n=0; self.wins=0; self.evaluations=[]; self.skipped=0; self.closed=[]

    def logistic(self, x):
        return sigmoid(self.weights[0]+sum(w*v for w,v in zip(self.weights[1:],x)))

    def assess(self,x):
        assessment=self.experts.assess(x,self.logistic(x))
        predictions=self.council.predictions(x)
        champion=self.council.report()['champion']
        assessment['legacy_score']=assessment['score']
        assessment['council_predictions']=predictions
        assessment['champion']=champion
        if champion is not None and predictions[champion] is not None:
            difference=abs(assessment['score']-predictions[champion])
            assessment['score']=(assessment['score']+predictions[champion])/2
            if difference>.35:
                assessment['abstain']=True
                assessment['reason']='Zusatzmodell und bisheriges Ensemble widersprechen sich'
        return assessment

    def predict(self,x):
        return self.assess(x)['score']

    def update(self, x, label):
        err=label-self.logistic(x)
        step=.08/math.sqrt(1+self.n/100)
        self.weights[0]+=step*err
        for i,v in enumerate(x,1):
            self.weights[i]+=step*(err*v-.01*self.weights[i])
        self.council.update(x,label)
        self.experts.update(x,label)
        self.n+=1; self.wins+=label

    def status(self, cfg):
        ev=self.evaluations[-100:]
        brier=sum((p-y)**2 for p,b,y in ev)/len(ev) if ev else None
        base=sum((b-y)**2 for p,b,y in ev)/len(ev) if ev else None
        enough=self.n>=cfg['ai_min_closed_trades'] and len(ev)>=cfg['ai_min_validation_trades']
        recent=ev[-20:]
        drift=len(recent)>=20 and sum((p-y)**2-(b-y)**2 for p,b,y in recent)/len(recent)>.02
        ready=bool(enough and not drift and brier+cfg['ai_min_brier_improvement']<base)
        return {'mode':'ranking' if ready else 'observing','drift_paused':drift,'expert_count':13,'council':self.council.report(),'memory_examples':len(self.experts.examples),'model_version':'council-v1', 'closed_trades':self.n,
                'validation_trades':len(ev), 'brier':brier, 'baseline_brier':base,
                'min_closed_trades':cfg['ai_min_closed_trades'],
                'min_validation_trades':cfg['ai_min_validation_trades'],
                'skipped_trades':self.skipped,
                'message':('Lokales Ensemble priorisiert Kandidaten mit gleichem Regel-Score' if ready else
                           'KI lernt; bisherige Einstiegsreihenfolge bleibt aktiv')}


def rebuild(path, chain_filter=None):
    """Replay ledger in event order; malformed or out-of-order ledgers fail closed.

    Missing feature sets are skipped rather than filled with invented values.
    BUY probability/baseline is stored until that position has fully closed.
    """
    model=Model(); active={}; previous=None
    if not path.exists(): return model
    with path.open(newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            stamp=datetime.fromisoformat(row['time'].replace('Z','+00:00'))
            if stamp.tzinfo is None: raise ValueError('Trade-Zeit ohne Zeitzone')
            stamp=stamp.astimezone(timezone.utc)
            if previous is not None and stamp<previous: raise ValueError('Trades nicht chronologisch')
            previous=stamp
            chain=trade_chain(row)
            if chain_filter is not None and chain!=chain_filter:continue
            token=(chain,normalize(chain,row['token'])); action=row['action']
            pnl=float(row['pnl_eur']); fraction=float(row['fraction'])
            if not math.isfinite(pnl) or not math.isfinite(fraction): raise ValueError('Ungültiger Trade')
            if action=='BUY':
                if token in active: raise ValueError('Überlappende Käufe desselben Tokens')
                try:
                    score=re.search(r'(?:^|;)score=([0-9.]+)',row['reason']).group(1)
                    x=features(float(score),row['reason'])
                    if not all(math.isfinite(v) for v in x): raise ValueError('Ungültige Features')
                except (ValueError,AttributeError):x=None
                assessment=model.assess(x) if x else None
                active[token]={'x':x,'pnl':pnl,'remaining':1.0,
                               'opened_at':stamp.timestamp(),'size':float(row['gross_eur']),
                               'entry_price':float(row['price_usd']),'entry_fee':-pnl,'exit_cost':0.0,
                               'symbol':row['symbol'],'entry_reason':row['reason'],
                               'prediction':assessment['score'] if assessment else None,
                               'council_predictions':assessment['council_predictions'] if assessment else {},
                               'legacy_score':assessment['legacy_score'] if assessment else None,
                               'baseline':(model.wins+1)/(model.n+2),'train_count':model.n}
            elif action=='SELL':
                if token not in active: raise ValueError('Verkauf ohne zugehörigen Kauf')
                t=active[token]
                if fraction<=0 or fraction>t['remaining']+1e-5: raise ValueError('Ungültiger Verkaufsanteil')
                if t['entry_price']>0:
                    theoretical=(t['size']-t['entry_fee'])*fraction*float(row['price_usd'])/t['entry_price']
                    t['exit_cost']+=max(0,theoretical-float(row['gross_eur']))
                t['pnl']+=pnl;t['remaining']-=fraction
                if t['remaining']<=1e-5:
                    del active[token]
                    model.closed.append({"key":f"{token[0]}:{token[1]}","net_pnl":t["pnl"],"closed_at":stamp.timestamp(),
                        "opened_at":t["opened_at"],"chain":chain,"symbol":t["symbol"],"size":t["size"],
                        "costs_eur":t["entry_fee"]+t["exit_cost"],"exit_reason":row["reason"].split(";")[-1],
                        "entry_reason":t["entry_reason"]})
                    if t['x'] is None:model.skipped+=1;continue
                    label=int(t['pnl']>0)
                    if t['train_count']>=20:
                        model.evaluations.append((t['prediction'],t['baseline'],label))
                        model.council.evaluate(t['council_predictions'],t['legacy_score'],label)
                    model.update(t['x'],label)
            else: raise ValueError('Unbekannte Trade-Aktion')
    return model


class Learner:
    def __init__(self, chain="solana"): self.signature=None;self.model=None;self.chain=chain
    def load(self,path):
        stat=path.stat() if path.exists() else None
        signature=(str(path), stat.st_mtime_ns if stat else 0, stat.st_size if stat else 0)
        if self.model is None or self.signature!=signature:
            model=rebuild(path,self.chain)
            self.model=model;self.signature=signature
        return self.model
