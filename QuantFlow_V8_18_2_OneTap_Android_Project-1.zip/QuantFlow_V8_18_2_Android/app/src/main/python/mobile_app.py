#!/usr/bin/env python
"""Read-only mobile dashboard server for Paper Bot V8.

Important: this process never scans markets, opens positions, closes positions,
or writes state.json/trades.csv. Only bot.py owns trading state.
"""
import csv
import json
import re
import threading
import time
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from candles import chart
from doctor import report as health_report
from backtest import summary as backtest_summary
from chains import LABELS, normalize, trade_chain
from trade_statistics import read_statistics

ROOT = Path(os.environ.get("BOT_DATA_DIR", str(Path(__file__).resolve().parent)))
DATA = ROOT / "mobile_scan.json"
STATE = ROOT / "state.json"
CONFIG_FILE = ROOT / "config.json"
SNAPSHOT = ROOT / "scanner_snapshot.json"
TRADES = ROOT / "trades.csv"


def read_json(path, default):
    for _ in range(2):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            time.sleep(0.05)
    return default


def read_trades():
    if not TRADES.exists():
        return []
    try:
        with TRADES.open(newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))
    except Exception:
        return []


def split_position_key(key):
    if ":" in key:
        return key.split(":", 1)
    return "solana", key



def build_trade_groups(rows, positions, cost_rate):
    groups = []
    current = {}
    fee_rate = float(cost_rate or 0.0)
    for idx, row in enumerate(rows):
        action = str(row.get("action") or "").upper()
        token = str(row.get("token") or "")
        chain = trade_chain(row)
        key = f"{chain}:{normalize(chain,token)}"
        if action == "BUY":
            gross = float(row.get("gross_eur") or 0)
            entry_fee = abs(float(row.get("pnl_eur") or 0))
            g = {
                "id": f"{idx}-{chain}-{token}", "time": row.get("time", ""),
                "symbol": row.get("symbol", "?"), "token": token, "chain": chain,
                "score": None, "entry_price": float(row.get("price_usd") or 0),
                "gross_eur": gross, "entry_fee_eur": entry_fee,
                "net_invested_eur": max(0.0, gross - entry_fee), "reason": row.get("reason", "") or "",
                "exits": [], "realized_pnl_eur": -entry_fee, "status": "OPEN",
                "remaining_fraction": 1.0, "unrealized_pnl_eur": 0.0,
                "current_price": float(row.get("price_usd") or 0),
                "current_value_eur": max(0.0, gross - entry_fee),
            }
            m = re.search(r"score=([0-9]+(?:\.[0-9]+)?)", str(row.get("reason") or ""))
            if m:
                g["score"] = float(m.group(1))
            current[key] = g
            groups.append(g)
        elif action == "SELL" and key in current:
            g = current[key]
            pnl = float(row.get("pnl_eur") or 0)
            frac = float(row.get("fraction") or 0)
            net = float(row.get("gross_eur") or 0)
            g["exits"].append({
                "time": row.get("time", ""), "price_usd": float(row.get("price_usd") or 0),
                "fraction": frac, "gross_eur": net, "pnl_eur": pnl,
                "reason": str(row.get("reason") or "").split(";", 1)[-1],
            })
            g["realized_pnl_eur"] += pnl
            sold = sum(float(x.get("fraction") or 0) for x in g["exits"])
            if sold >= 0.999999:
                g["status"] = "CLOSED"; g["remaining_fraction"] = 0.0
                current.pop(key, None)
            else:
                g["status"] = "PARTIAL"; g["remaining_fraction"] = max(0.0, 1.0 - sold)

    for g in groups:
        key = f"{g['chain']}:{normalize(g['chain'],g['token'])}"
        pos = positions.get(key)
        if pos and g["status"] != "CLOSED":
            remaining = float(pos.get("remaining_fraction", 1.0))
            current_price = float(pos.get("current_price") or g["entry_price"])
            invested_remaining = float(pos.get("invested_eur") or 0) * remaining
            current_value = invested_remaining * (current_price / g["entry_price"]) if g["entry_price"] else invested_remaining
            estimated_exit_cost = current_value * fee_rate
            g["status"] = "OPEN" if remaining >= 0.999999 else "PARTIAL"
            g["remaining_fraction"] = remaining
            g["high_price"] = float(pos.get("high_price") or g["entry_price"])
            g["opened_at"] = pos.get("opened_at", g["time"])
            g["current_price"] = current_price
            g["current_value_eur"] = current_value
            g["unrealized_pnl_eur"] = current_value - invested_remaining - estimated_exit_cost
            g["tp1_done"] = bool(pos.get("tp1_done")); g["tp2_done"] = bool(pos.get("tp2_done"))

    for g in groups:
        g["exit_count"] = len(g["exits"])
        denom = g["gross_eur"] or 0
        g["total_pnl_eur"] = float(g["realized_pnl_eur"]) + float(g.get("unrealized_pnl_eur") or 0)
        g["pnl_pct"] = (g["total_pnl_eur"] / denom * 100) if denom else 0.0
        g["realized_pnl_pct"] = (g["realized_pnl_eur"] / denom * 100) if denom else 0.0
        g["entry_price_label"] = f"{g['entry_price']:.10g}"
    return groups


def make_positions(state):
    out = []
    pos_map = {}
    for key, pos in (state.get("positions") or {}).items():
        chain, token = split_position_key(key)
        entry = float(pos.get("entry_price") or 0)
        price = float(pos.get("current_price") or entry or 0)
        item = {
            "key": key, "symbol": pos.get("symbol", "?"), "chain": LABELS.get(chain,chain),
            "chain_id": chain, "token": token, "entry_price": entry, "current_price": price,
            "remaining_fraction": float(pos.get("remaining_fraction", 1.0)),
            "high_price": float(pos.get("high_price") or entry or 0),
            "change_pct": ((price / entry) - 1) * 100 if entry else 0.0,
            "invested_eur": float(pos.get("invested_eur") or 0), "score": pos.get("score"),
            "exit_plan": pos.get("exit_plan"), "entry_budget": pos.get("entry_budget"),
            "opened_at": pos.get("opened_at", ""), "tp1_done": bool(pos.get("tp1_done")),
            "tp2_done": bool(pos.get("tp2_done")), "pair_address": pos.get("pair_address", ""),
        }
        out.append(item)
        pos_map[key] = pos
    return out, pos_map


def local_portfolio_value(state, cfg):
    total = float(state.get("cash_eur", 0))
    exit_rate = (float(cfg.get("paper_slippage_pct", 0)) + float(cfg.get("paper_fee_pct", 0))) / 100.0
    for pos in (state.get("positions") or {}).values():
        entry = float(pos.get("entry_price") or 0)
        price = float(pos.get("current_price") or entry or 0)
        if entry <= 0:
            continue
        value = float(pos.get("invested_eur", 0)) * float(pos.get("remaining_fraction", 1)) * (price / entry)
        total += value * (1.0 - exit_rate)
    return total


def required_json(path):
    value=read_json(path,None)
    if not isinstance(value,dict):raise ValueError(path.name+" fehlt oder ist unlesbar")
    return value


def build_payload():
    cfg = required_json(CONFIG_FILE)
    state = required_json(STATE)
    if "cash_eur" not in state or not isinstance(state.get("positions"),dict):
        raise ValueError("state.json: Cash oder Positionen fehlen")
    scan = read_json(SNAPSHOT, {})
    positions, pos_map = make_positions(state)
    rows = read_trades()
    rate = (float(cfg.get("paper_slippage_pct", 0)) + float(cfg.get("paper_fee_pct", 0))) / 100.0
    groups = build_trade_groups(rows, pos_map, rate)
    realized_today = float(state.get("day_realized_pnl_eur", 0) or 0)
    open_unrealized = sum(float(g.get("unrealized_pnl_eur") or 0) for g in groups if g.get("status") != "CLOSED")
    payload = {
        "cash_eur": float(state.get("cash_eur", 0)),
        "realized_pnl_eur": float(state.get("realized_pnl_eur", 0)),
        "day_realized_pnl_eur": realized_today, "unrealized_pnl_eur": open_unrealized,
        "total_today_pnl_eur": local_portfolio_value(state, cfg) - float(state.get("day_start_equity_eur", cfg.get("initial_capital_eur", 100))),
        "trades_today": int(state.get("trades_today", 0)),
        "portfolio_value": local_portfolio_value(state, cfg),
        "position_count": len(state.get("positions") or {}), "positions": positions,
        "statistics": read_statistics(TRADES, float(cfg.get("initial_capital_eur",100))),
        "backtests": backtest_summary(ROOT / "backtests.sqlite3"),
        "strategy_database": scan.get("strategy_database", {}),
        "scan_running": bool(scan.get("scan_running")),
        "scan_elapsed_seconds": scan.get("scan_elapsed_seconds",0),
        "ai": scan.get("ai", {}),
        "coverage": scan.get("coverage", {}),
        "discovery": scan.get("discovery", {}),
        "context": scan.get("context", {}), "loss_pauses": scan.get("loss_pauses", {}),
        "discovery_errors": scan.get("discovery_errors", []),
        "counts": scan.get("counts", {}), "reasons": scan.get("reasons", {}),
        "near": scan.get("near", []), "best": scan.get("best"),
        "trades": rows, "trade_groups": groups, "config": cfg,
        "scan_updated_epoch": scan.get("updated_at_epoch", 0),
        "time": scan.get("time", time.strftime("%H:%M:%S")),
        "status": scan.get("status", "Bot-Daten werden erwartet · Dashboard ist read-only · PAPER only"),
    }
    heartbeat = float(scan.get("updated_at_epoch", 0))
    age = max(0, time.time() - heartbeat) if heartbeat else None
    stale = age is None or age > 90
    payload.update(instance=f"{cfg.get('version', 'paper')}-parallel", version=cfg.get("version"),
                   scan_age_seconds=age, stale=stale,
                   daily_halt=bool(state.get("daily_halt")),
                   drawdown_halt=bool(state.get("drawdown_halt")))
    worker_stamp = float(scan.get("heartbeat_epoch", 0))
    worker_age = max(0, time.time()-worker_stamp) if worker_stamp else None
    payload["worker_age_seconds"] = worker_age
    if worker_age is not None and worker_age > 90:
        payload["status"] = "Bot-Lebenszeichen veraltet – Termux prüfen"
    elif stale and scan.get("scan_running"):
        payload["status"] = "Scanner arbeitet · letzte fertige Scandaten sind veraltet"
    elif stale:
        payload["status"] = "Keine aktuellen Scandaten – Bot oder Verbindung prüfen"
    elif scan.get("feed_errors"):
        payload["status"] = "Marktdaten unvollständig – Verbindungsfehler"
    return payload


def serve(host="127.0.0.1", port=8766):
    server = ThreadingHTTPServer((host, port), H)
    print(f"{read_json(CONFIG_FILE, {}).get('version', 'PAPER')} Dashboard: http://{host}:{port}", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


class H(BaseHTTPRequestHandler):
    def sendb(self, b, t):
        self.send_response(200); self.send_header("Content-Type", t); self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p = urlparse(self.path).path
        if p == "/": self.sendb((ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif p == "/manifest.json" and (ROOT / "manifest.json").exists(): self.sendb((ROOT / "manifest.json").read_bytes(), "application/manifest+json")
        elif p == "/sw.js" and (ROOT / "sw.js").exists(): self.sendb((ROOT / "sw.js").read_bytes(), "application/javascript")
        elif p == "/api/health":
            try:
                from doctor import report
                body=report(ROOT)
            except Exception as exc:body={"error":str(exc),"stale":True}
            self.sendb(json.dumps(body,allow_nan=False).encode("utf-8"),"application/json")
        elif p == "/api/status":
            try:body=json.dumps(build_payload(),ensure_ascii=False,allow_nan=False)
            except Exception as exc:body=json.dumps({"error":str(exc),"stale":True,"status":"Datenfehler – keine aktuellen Werte bestätigt"})
            self.sendb(body.encode("utf-8"),"application/json")
        elif p in ('/council_ui.js','/trade_days.js','/local_time.js','/cyber.css','/cyber.js','/tradingview.js'):
            self.sendb((ROOT / p[1:]).read_bytes(), 'text/css' if p.endswith('.css') else 'application/javascript')
        elif p == '/api/candles':
            q=parse_qs(urlparse(self.path).query)
            result=chart(*(q.get(k,[''])[0] for k in ('chain','pool','token','frame')))
            self.sendb(json.dumps(result,allow_nan=False).encode(), 'application/json')
        else: self.send_error(404)
    def log_message(self, *a): pass


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    serve(port=args.port)
