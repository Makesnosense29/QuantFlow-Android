import strategy
from strategy_lab_v818 import FocusedStrategyLab
import csv
from datetime import datetime, timezone
import json
import logging
import math
from logging.handlers import RotatingFileHandler
import os
import sys
import time
from pathlib import Path

from urllib.request import Request, urlopen
from urllib.error import HTTPError
from dashboard import render
from learning import Learner, FEATURES, features
from chains import LABELS, normalize, trade_chain
from market import Universe
from context_guard import market_context, loss_pauses
from trade_statistics import read_statistics
from concurrent.futures import ThreadPoolExecutor
import threading
import signal
from collections import deque
from urllib.parse import quote

BASE = Path(os.environ.get("BOT_DATA_DIR", str(Path(__file__).resolve().parent)))
CONFIG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
STATE_FILE = BASE / "state.json"
TRADES_FILE = BASE / "trades.csv"
IS_TEST_PROCESS = ("unittest" in sys.modules) or os.environ.get("BOT_TEST_MODE") == "1"
LOG_FILE = Path(os.environ.get("BOT_LOG_FILE", str(BASE / "bot.log")))
SNAPSHOT_FILE = BASE / "scanner_snapshot.json"
LOCK_FILE = BASE / ".paper_bot.lock"

_log_handlers = ([logging.NullHandler()] if IS_TEST_PROCESS else
                 [RotatingFileHandler(LOG_FILE, maxBytes=2_000_000, backupCount=3, encoding="utf-8"), logging.StreamHandler()])
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s", handlers=_log_handlers, force=True)
log = logging.getLogger("paperbot")
USER_AGENT = f"MultiChainPaperBot/{CONFIG.get('version', 'paper')}"
CHAIN_LABELS = LABELS
ENABLED_CHAINS = CONFIG["enabled_chains"]
UNIVERSE = Universe(BASE / "universe.json")
LAB = None
LAB_STATUS = {}
COVERAGE = {}
CONTEXT = {}
LOSS_PAUSES = {}
HISTORY = Learner(chain=None)
REQUEST_LOCKS = {"fast": threading.Lock(), "slow": threading.Lock()}
LAST_REQUEST = {"fast": 0.0, "slow": 0.0}
API_STATUS = {"fast_requests": 0, "slow_requests": 0, "rate_limited": 0, "errors": 0}
SIGNAL_CACHE = {}
FEED_ERRORS = deque(maxlen=100)
ERROR_LOCK = threading.Lock()
STOP = threading.Event()

def recent_feed_errors():
    with ERROR_LOCK:
        return [name for stamp, name in FEED_ERRORS if time.time()-stamp < 90]
LEARNER = Learner()
CHAIN_LEARNERS = {c: Learner(c) for c in ENABLED_CHAINS if c != "solana"}
AI_STATUS = {"mode": "observing", "message": "KI wartet auf Trade-Auswertung"}
AI_MODEL_SIGNATURE = {}
OBSERVATIONS = logging.getLogger("observations")
OBSERVATIONS.setLevel(logging.INFO)
OBSERVATIONS.propagate = False
if IS_TEST_PROCESS:
    OBSERVATIONS.addHandler(logging.NullHandler())
else:
    _handler = RotatingFileHandler(BASE / "observations.jsonl", maxBytes=10_000_000, backupCount=5, encoding="utf-8")
    _handler.setFormatter(logging.Formatter("%(message)s"))
    OBSERVATIONS.addHandler(_handler)


def record_observation(kind, payload):
    OBSERVATIONS.info(json.dumps({"time": now_iso(), "kind": kind, **payload}, allow_nan=False))


def token_entry_allowed(s, key):
    return int(s.get("token_entries_today", {}).get(key, 0)) < int(CONFIG["max_entries_per_token_per_day"])


def restore_token_counts(s):
    counts = {}
    recent = []
    if TRADES_FILE.exists():
        with TRADES_FILE.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["action"] == "BUY":
                    stamp = datetime.fromisoformat(row["time"].replace("Z", "+00:00"))
                    if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
                    if time.time()-stamp.timestamp()<60:recent.append(stamp.timestamp())
                if row["action"] == "BUY" and row["time"][:10] == today_utc():
                    key = position_key(trade_chain(row), row["token"])
                    counts[key] = counts.get(key, 0) + 1
    s["entry_times"] = recent
    s["token_entries_today"] = counts



def now_iso():
    return datetime.now(timezone.utc).isoformat()


def today_utc():
    return datetime.now(timezone.utc).date().isoformat()


def atomic_write_json(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def _request_group(url):
    slow_markers = ("/token-profiles/", "/token-boosts/", "/community-takeovers/", "/ads/", "/orders/")
    return "slow" if any(marker in url for marker in slow_markers) else "fast"


def get_json(url, timeout=5):
    """Rate-aware DEX Screener GET with bounded 429 backoff.

    DEX Screener documents separate 60 rpm and 300 rpm endpoint families.  Keep
    independent clocks so slow discovery calls cannot stall fast pair quotes.
    """
    group = _request_group(url)
    interval = float(CONFIG.get("dexscreener_slow_min_interval_seconds", 1.05) if group == "slow"
                     else CONFIG.get("dexscreener_fast_min_interval_seconds", 0.22))
    last = None
    for attempt in range(3):
        if STOP.is_set():
            raise RuntimeError("Bot wird beendet")
        try:
            with REQUEST_LOCKS[group]:
                delay = max(0.0, interval - (time.monotonic() - LAST_REQUEST[group]))
                if STOP.wait(delay):
                    raise RuntimeError("Bot wird beendet")
                LAST_REQUEST[group] = time.monotonic()
                API_STATUS[group + "_requests"] += 1
            request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
            with urlopen(request, timeout=timeout) as response:
                return json.load(response)
        except HTTPError as exc:
            last = exc
            if exc.code == 429:
                API_STATUS["rate_limited"] += 1
                raw = exc.headers.get("Retry-After") if exc.headers else None
                try: wait = float(raw)
                except (TypeError, ValueError): wait = 1.5 * (attempt + 1)
                wait = min(max(wait, interval), float(CONFIG.get("http_retry_after_cap_seconds", 15.0)))
                if attempt < 2 and not STOP.wait(wait):
                    continue
            break
        except Exception as exc:
            last = exc
            if attempt < 2 and not STOP.wait(0.35 * (attempt + 1)):
                continue
            break
    API_STATUS["errors"] += 1
    with ERROR_LOCK:
        FEED_ERRORS.append((time.time(), type(last).__name__))
    raise last


def position_key(chain_id, token):
    return f"{chain_id}:{normalize(chain_id, token)}"


def split_position_key(key):
    if ":" in key:
        chain_id, token = key.split(":", 1)
        return chain_id, token
    return "solana", key


def default_state():
    return {
        "cash_eur": float(CONFIG["initial_capital_eur"]),
        "realized_pnl_eur": 0.0,
        "positions": {},
        "day": today_utc(),
        "day_realized_pnl_eur": 0.0,
        "trades_today": 0,
        "cooldowns": {},
        "token_entries_today": {},
        "accounting_version": 2,
    }


def load_state():
    if not STATE_FILE.exists():
        return default_state()
    try:
        s = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        log.exception("state.json unlesbar; Bot stoppt statt State zu überschreiben")
        raise
    if not isinstance(s.get("positions", {}), dict):
        raise ValueError("state.json: positions muss ein Objekt/dict sein")
    if s.get("day") != today_utc():
        s["day"] = today_utc()
        s["day_realized_pnl_eur"] = 0.0
        s["trades_today"] = 0
        s["token_entries_today"] = {}
        # Keep cooldowns across UTC midnight.
        s["day_start_equity_eur"] = portfolio_value(s)
        s["daily_halt"] = False
    s.setdefault("positions", {})
    s.setdefault("cooldowns", {})
    s.setdefault("realized_pnl_eur", 0.0)
    s.setdefault("day_realized_pnl_eur", 0.0)
    s.setdefault("trades_today", 0)
    s.setdefault("accounting_version", 1)
    restore_token_counts(s)
    return s


def save_state(s):
    atomic_write_json(STATE_FILE, s)


def append_trade(row):
    exists = TRADES_FILE.exists()
    fields = ["time", "action", "symbol", "token", "price_usd", "fraction", "gross_eur", "pnl_eur", "reason"]
    with TRADES_FILE.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        w.writerow(row)
        f.flush()


def metric(d, bucket, default=0.0):
    try:
        value = float((d or {}).get(bucket, default) or default)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def pair_age_minutes(p):
    ms = p.get("pairCreatedAt")
    if not ms:
        return 0.0
    try:
        return max(0.0, (time.time() * 1000 - float(ms)) / 60000.0)
    except (TypeError, ValueError):
        return 0.0


def chain_rules(chain_id):
    return CONFIG.get("chain_rules", {}).get(chain_id, CONFIG.get("chain_rules", {}).get("solana", {}))


def same_pair_address(chain_id, left, right):
    a, b = str(left or ""), str(right or "")
    return a == b if chain_id == "solana" else a.lower() == b.lower()


def pair_usable_for_token(p, token, chain_id="solana"):
    if not isinstance(p, dict):
        return False
    base = str((p.get("baseToken") or {}).get("address") or "")
    if normalize(chain_id, base) != normalize(chain_id, token):
        return False
    try:
        price = float(p.get("priceUsd") or 0)
        liq = float((p.get("liquidity") or {}).get("usd") or 0)
    except (TypeError, ValueError):
        return False
    return (math.isfinite(price) and math.isfinite(liq) and price > 0 and liq > 0
            and p.get("chainId") == chain_id and bool(p.get("pairAddress")))


def latest_tokens():
    return UNIVERSE.discover(get_json, CONFIG)


def fetch_chain_pairs(tokens, chain_id="solana"):
    """Batch-load candidate pairs. DEX Screener supports up to 30 token addresses/request."""
    best = {}
    for i in range(0, len(tokens), 30):
        chunk = tokens[i:i + 30]
        if not chunk:
            continue
        try:
            data = get_json(f"https://api.dexscreener.com/tokens/v1/{chain_id}/" + quote(",".join(chunk),safe=","))
        except RuntimeError:
            if STOP.is_set():
                break
            raise
        except Exception as e:
            log.warning("DexScreener Batch-Feed fehlgeschlagen: %s", e)
            continue
        if isinstance(data, dict):
            data = data.get("pairs") or []
        if not isinstance(data, list):
            continue
        wanted = set(chunk)
        for p in data:
            if not isinstance(p,dict):continue
            token = normalize(chain_id, (p.get("baseToken") or {}).get("address") or "")
            if token not in wanted or not pair_usable_for_token(p, token, chain_id):
                continue
            old = best.get(token)
            liq = metric(p.get("liquidity"), "usd")
            if old is None or liq > metric(old.get("liquidity"), "usd"):
                p.setdefault("chainId", chain_id)
                p["_received_epoch"] = time.time()
                best[token] = p
    return best


def fetch_open_position_pairs(s):
    """Batch-load exact stored pools for open positions when the token endpoint returns them.

    Missing pools are intentionally not substituted; manage_positions falls back to the
    exact-pair endpoint. This reduces request load without changing pair identity.
    """
    grouped = {}
    for key, pos in s.get("positions", {}).items():
        chain_id, token = split_position_key(key)
        pair_address = pos.get("pair_address")
        if not pair_address or chain_id not in LABELS:
            continue
        grouped.setdefault(chain_id, {})[normalize(chain_id, token)] = str(pair_address)
    found = {}
    for chain_id, wanted in grouped.items():
        tokens = list(wanted)
        for i in range(0, len(tokens), 30):
            chunk = tokens[i:i + 30]
            if not chunk:
                continue
            try:
                data = get_json(f"https://api.dexscreener.com/tokens/v1/{chain_id}/" + quote(",".join(chunk), safe=","))
            except RuntimeError:
                if STOP.is_set():
                    return found
                raise
            except Exception as exc:
                log.warning("Positions-Batch %s fehlgeschlagen: %s", chain_id, exc)
                continue
            if isinstance(data, dict):
                data = data.get("pairs") or []
            for pair in data if isinstance(data, list) else []:
                token = normalize(chain_id, (pair.get("baseToken") or {}).get("address") or "")
                target = wanted.get(token)
                if not target or not pair_usable_for_token(pair, token, chain_id):
                    continue
                if same_pair_address(chain_id, pair.get("pairAddress"), target):
                    pair["_received_epoch"] = time.time()
                    found[position_key(chain_id, token)] = pair
    return found


def best_pair(token, chain_id="solana", symbol=None, pair_address=None):
    if chain_id not in LABELS:
        return None
    if pair_address:
        data = get_json(f"https://api.dexscreener.com/latest/dex/pairs/{chain_id}/{quote(pair_address,safe='')}")
        pairs = data.get("pairs") or [] if isinstance(data, dict) else []
        for p in pairs:
            if same_pair_address(chain_id, p.get("pairAddress"), pair_address) and pair_usable_for_token(p, token, chain_id):
                return p
        return None
    pairs = get_json(f"https://api.dexscreener.com/token-pairs/v1/{chain_id}/{quote(token,safe='')}")
    if isinstance(pairs, dict):
        pairs = pairs.get("pairs") or []
    usable = [p for p in pairs if pair_usable_for_token(p, token, chain_id)] if isinstance(pairs, list) else []
    if not usable:
        return None
    usable.sort(key=lambda p: metric(p.get("liquidity"), "usd"), reverse=True)
    return usable[0]


def valid_signal_data(p):
    try:
        values = [p["priceUsd"], p["liquidity"]["usd"], p["volume"]["h1"],
                  p["priceChange"]["h1"], p["priceChange"]["m5"],
                  p["txns"]["h1"]["buys"], p["txns"]["h1"]["sells"], p["pairCreatedAt"]]
        return all(math.isfinite(float(v)) for v in values) and all(float(values[i]) >= 0 for i in (1,2,5,6,7))
    except (KeyError, TypeError, ValueError):
        return False


def validate_config():
    strategy.validate(CONFIG)
    if not 1000<=CONFIG['candidate_target']<=CONFIG['max_scan_candidates']<=2400:
        raise ValueError('Scanner-Ziel/Kapazität ungültig')
    if CONFIG['max_candidates_per_chain']<CONFIG['max_scan_candidates']:
        raise ValueError('Pro-Chain-Kapazität verhindert flexible Verteilung')
    if not 1<=CONFIG['pool_pages_per_network']<=10 or CONFIG['pool_request_interval_seconds']<6.5:
        raise ValueError('Pool-API-Limit ungültig')
    for key in ("context_min_sample","loss_pause_count"):
        if not isinstance(CONFIG[key],int) or CONFIG[key]<2:raise ValueError("Ungültige Kontext-Stichprobe")
    for key in ("context_min_quote_coverage","context_negative_share"):
        if not 0<CONFIG[key]<=1:raise ValueError("Ungültiger Kontext-Anteil")
    for key in ("loss_memory_hours","loss_pause_hours"):
        if CONFIG[key]<=0:raise ValueError("Ungültige Lernpause")
    if CONFIG["context_weak_median_m5_pct"]>=0:raise ValueError("Marktschwäche-Schwelle muss negativ sein")
    if not ENABLED_CHAINS or any(c not in LABELS for c in ENABLED_CHAINS):
        raise ValueError("Ungültige Blockchain-Auswahl")
    for key in ("discovery_refresh_seconds","max_universe_per_chain","max_candidates_per_chain"):
        if not isinstance(CONFIG[key],int) or CONFIG[key]<1:
            raise ValueError("Ungültiges Scanner-Limit")
    if not CONFIG["discovery_search_queries"]:
        raise ValueError("Suchbegriffe fehlen")
    for key, value in CONFIG.items():
        if isinstance(value, (int, float)) and not math.isfinite(value):
            raise ValueError(f"Ungültiger Konfigurationswert: {key}")
    if CONFIG.get("ai_mode") not in ("off", "observe", "adaptive_ranking"):
        raise ValueError("Ungültiger KI-Modus")
    for key in ("ai_min_closed_trades", "ai_min_validation_trades"):
        if not isinstance(CONFIG[key], int) or CONFIG[key] < 20:
            raise ValueError("KI benötigt mindestens 20 Beobachtungen je Prüfschwelle")
    if not 0 <= CONFIG["ai_min_brier_improvement"] < 1:
        raise ValueError("Ungültige KI-Validierungsschwelle")
    if CONFIG.get("mode") != "paper":
        raise ValueError("Nur Paper-Modus unterstützt")
    if not -100 < CONFIG["stop_loss_pct"] < 0 or not 0 <= costs(1) < 1:
        raise ValueError("Stop/Kosten ungültig")
    for key in ("initial_capital_eur", "position_size_eur", "min_position_size_eur",
                "max_daily_loss_eur", "risk_per_trade_pct", "max_drawdown_pct",
                "max_exposure_pct", "max_quote_age_seconds", "scan_interval_seconds",
                "market_scan_interval_seconds", "console_status_interval_seconds"):
        if CONFIG[key] <= 0:
            raise ValueError(f"{key} muss positiv sein")
    for key in ("max_open_positions", "max_trades_per_day", "max_new_positions_per_scan", "entry_confirmations"):
        if not isinstance(CONFIG[key], int) or CONFIG[key] < 1:
            raise ValueError(f"{key} muss eine positive Ganzzahl sein")
    if not 0 <= CONFIG["gap_buffer_pct"] < 100 + CONFIG["stop_loss_pct"]:
        raise ValueError("Ungültiger Gap-Puffer")
    if not isinstance(CONFIG["max_entries_per_token_per_day"], int) or CONFIG["max_entries_per_token_per_day"] < 1:
        raise ValueError("Ungültiges Token-Tageslimit")
    if CONFIG["entry_confirmations"] < 2:
        raise ValueError("Mindestens zwei Bestätigungen nötig")
    if float(CONFIG["market_scan_interval_seconds"]) < float(CONFIG["scan_interval_seconds"]):
        raise ValueError("Marktscan-Intervall darf nicht kleiner als Hauptintervall sein")
    if not isinstance(CONFIG.get("position_quote_batch_enabled"), bool):
        raise ValueError("Positions-Batch-Schalter muss bool sein")
    if not 0 < CONFIG["tp1_sell_fraction"] <= 1 or not 0 < CONFIG["tp2_sell_fraction"] <= 1:
        raise ValueError("Ungültige Teilverkaufsanteile")
    if float(CONFIG.get("dexscreener_fast_min_interval_seconds", 0)) < 0.20:
        raise ValueError("DEX-Screener-Fast-Limit zu aggressiv")
    if float(CONFIG.get("dexscreener_slow_min_interval_seconds", 0)) < 1.0:
        raise ValueError("DEX-Screener-Slow-Limit zu aggressiv")
    if float(CONFIG.get("stale_force_minutes", 0)) <= float(CONFIG.get("stale_exit_minutes", 0)):
        raise ValueError("Stale-Force muss nach dem ersten Zeitfenster liegen")
    missing=[chain for chain in ENABLED_CHAINS if chain not in CONFIG.get("chain_rules",{})]
    if missing:
        raise ValueError("Explizite Chain-Regeln fehlen: " + ",".join(missing))
    q=CONFIG.get("entry_quality_v818",{})
    if float(q.get("strong_m5_min_pct",0)) < 0 or float(q.get("strong_ratio_max",0)) <= 1:
        raise ValueError("V8.18-Entry-Ranking ungültig")


def pair_metrics(p):
    liq = metric(p.get("liquidity"), "usd")
    vol = metric(p.get("volume"), "h1")
    h1chg = metric(p.get("priceChange"), "h1")
    m5 = metric(p.get("priceChange"), "m5")
    tx = (p.get("txns") or {}).get("h1") or {}
    buys = float(tx.get("buys") or 0)
    sells = float(tx.get("sells") or 0)
    ratio = buys / max(sells, 1.0)
    age = pair_age_minutes(p)
    turnover = vol / max(liq, 1.0)
    return liq, vol, h1chg, m5, buys, sells, ratio, age, turnover


def score_pair(p, chain_id="solana"):
    rules = strategy.rules_for(p, chain_rules(chain_id), CONFIG)
    liq, vol, h1chg, m5, buys, sells, ratio, age, turnover = pair_metrics(p)
    score = 0
    score += 2 if liq >= rules.get("score_liquidity_2", 100000) else 1
    score += 2 if vol >= rules.get("score_volume_2", 100000) else 1
    ratio_ideal_min = float(rules.get("score_ratio_ideal_min", rules.get("score_ratio_2", 1.4)))
    ratio_ideal_max = float(rules.get("score_ratio_ideal_max", rules.get("max_buy_sell_ratio", 20.0)))
    score += 2 if ratio_ideal_min <= ratio <= ratio_ideal_max else 1
    if rules.get("score_h1_ideal_min", 5) <= h1chg <= rules.get("score_h1_ideal_max", 25):
        score += 2
    else:
        score += 1
    if rules.get("score_m5_ideal_min", -1) <= m5 <= rules.get("score_m5_ideal_max", 5):
        score += 1
    if age >= rules.get("score_age_minutes", 180):
        score += 1
    reason = (
        f"chain={chain_id};liq={liq:.0f},vol1h={vol:.0f},ratio={ratio:.2f},"
        f"chg1h={h1chg:.1f}%,m5={m5:.1f}%,age={age:.0f}m,turn={turnover:.2f}"
    )
    return min(10, score), reason


def entry_quality_rank(p, chain_id="solana"):
    """Small transparent ranking preference; never overrides hard risk filters."""
    _, _, h1chg, m5, _, _, ratio, _, _ = pair_metrics(p)
    q = CONFIG.get("entry_quality_v818", {})
    points = 0
    if m5 >= float(q.get("strong_m5_min_pct", 1.0)):
        points += 2
    if ratio <= float(q.get("strong_ratio_max", 2.5)):
        points += 2
    if h1chg >= float(q.get("strong_h1_min_pct", 2.0)):
        points += 1
    return points


def costs(amount):
    pct = (float(CONFIG.get("paper_slippage_pct", 0)) + float(CONFIG.get("paper_fee_pct", 0))) / 100.0
    return float(amount) * pct


def update_risk(s):
    equity = portfolio_value(s)
    s.setdefault("day_start_equity_eur", equity)
    s["peak_equity_eur"] = max(float(s.get("peak_equity_eur", equity)), equity)
    daily_loss = float(s["day_start_equity_eur"]) - equity
    if daily_loss >= float(CONFIG["max_daily_loss_eur"]):
        s["daily_halt"] = True
    peak = s["peak_equity_eur"]
    if peak > 0 and (peak - equity) / peak * 100 >= float(CONFIG["max_drawdown_pct"]):
        s["drawdown_halt"] = True
    return equity


def entry_size_for_score(score, cash, equity=None):
    equity = float(cash if equity is None else equity)
    rate = costs(1)
    # Size for an adverse move beyond the stop; this is still not a loss guarantee.
    stress_return = (float(CONFIG["stop_loss_pct"]) - float(CONFIG["gap_buffer_pct"])) / 100
    loss_fraction = 1 - (1-rate)**2 * (1 + stress_return)
    risk_size = equity * float(CONFIG["risk_per_trade_pct"])/100 / loss_fraction
    return max(0, min(float(CONFIG["position_size_eur"]), float(cash), risk_size))


def can_open(s, minimum_eur=None):
    equity = update_risk(s)
    if s.get("daily_halt") or s.get("drawdown_halt"):
        return False
    if len(s["positions"]) >= int(CONFIG["max_open_positions"]):
        return False
    if len([x for x in s.get("entry_times",[]) if time.time()-float(x)<60]) >= strategy.fast_settings(CONFIG)["entries_per_minute"]:
        return False
    if int(s.get("trades_today", 0)) >= int(CONFIG["max_trades_per_day"]):
        return False
    for pos in s["positions"].values():
        stamp = float(pos.get("quote_received_at", 0))
        if time.time() - stamp > float(CONFIG["max_quote_age_seconds"]):
            return False
    minimum = float(CONFIG["min_position_size_eur"] if minimum_eur is None else minimum_eur)
    size = strategy.allocation(s, CONFIG, equity, strategy.make_plan({}, CONFIG, costs(1)), costs(1))["gross_eur"]
    exposure = sum(float(p["invested_eur"])*float(p["remaining_fraction"])
                   for p in s["positions"].values())
    return (size >= minimum and exposure + size <= equity * float(CONFIG["max_exposure_pct"])/100)


def open_position(s, p, chain_id, score, reason):
    if STOP.is_set():
        return False
    token = str((p.get("baseToken") or {}).get("address") or "")
    key = position_key(chain_id, token)
    if not token or key in s["positions"] or not token_entry_allowed(s, key) or not can_open(s):
        return False
    price = float(p.get("priceUsd") or 0)
    if chain_id not in ENABLED_CHAINS or not pair_usable_for_token(p, token, chain_id):
        return False
    plan = strategy.make_plan(p, CONFIG, costs(1))
    for extra in ("stale_exit_requires_weak_flow", "stale_exit_m5_max_pct", "stale_force_minutes", "stale_force_max_net_return_pct"):
        if extra in CONFIG:
            plan[extra] = CONFIG[extra]
    # Freeze the strategy generation into each new position.  Existing V8.16/V8.17
    # positions keep their own already-frozen exit plan during an upgrade.
    plan["strategy_version"] = CONFIG.get("version", "paper")
    budget = strategy.allocation(s, CONFIG, portfolio_value(s), plan, costs(1))
    gross = budget["gross_eur"]
    min_size = float(CONFIG["min_position_size_eur"])
    if gross + 1e-9 < min_size:
        return False
    entry_cost = costs(gross)
    invested = gross - entry_cost
    s["cash_eur"] -= gross
    # Accounting V2: entry friction is realized immediately, so dashboard PnL
    # equals the sum of BUY+SELL pnl_eur in trades.csv going forward.
    s["realized_pnl_eur"] = float(s.get("realized_pnl_eur", 0)) - entry_cost
    s["day_realized_pnl_eur"] = float(s.get("day_realized_pnl_eur", 0)) - entry_cost
    s["accounting_version"] = 2
    s["positions"][key] = {
        "symbol": (p.get("baseToken") or {}).get("symbol", "?"),
        "chain_id": chain_id,
        "exit_plan": plan, "entry_budget": budget,
        "entry_gross_eur": gross, "exit_net_received_eur": 0.0,
        "entry_price": price,
        "current_price": price,
        "quote_received_at": time.time(),
        "remaining_fraction": 1.0,
        "invested_eur": invested,
        "high_price": price,
        "tp1_done": False,
        "tp2_done": False,
        "opened_at": now_iso(),
        "score": score,
        "pair_address": p.get("pairAddress"),
        "dex_id": p.get("dexId"),
        "quote_symbol": (p.get("quoteToken") or {}).get("symbol", "?"),
    }
    s["entry_times"] = [x for x in s.get("entry_times",[]) if time.time()-float(x)<60]+[time.time()]
    s["trades_today"] = int(s.get("trades_today", 0)) + 1
    counts = s.setdefault("token_entries_today", {})
    counts[key] = counts.get(key, 0) + 1
    append_trade({
        "time": now_iso(), "action": "BUY", "symbol": s["positions"][key]["symbol"],
        "token": token, "price_usd": price, "fraction": 1,
        "gross_eur": round(gross, 4), "pnl_eur": round(-entry_cost, 4),
        "reason": f"{LABELS[chain_id]};score={score};{reason};profile={plan['profile']};stop={plan['stop_loss_pct']};tp1={plan['take_profit_1_pct']:.4f};tp2={plan['take_profit_2_pct']:.4f};version={CONFIG['version']}",
    })
    log.info("PAPER BUY %s %.2f EUR @ %.8g | score=%s | pair=%s", s["positions"][key]["symbol"], gross, price, score, p.get("pairAddress"))
    SIGNAL_CACHE.pop(key, None)
    save_state(s)
    return True


def set_cooldown(s, key, reason):
    mins = float(CONFIG.get("stop_cooldown_minutes", 60) if reason == "STOP" else CONFIG.get("normal_cooldown_minutes", 20))
    s.setdefault("cooldowns", {})[key] = time.time() + mins * 60.0


def sell_fraction(s, key, p, fraction_of_original, reason):
    pos = s["positions"].get(key)
    if not pos:
        return False
    fraction = min(float(fraction_of_original), float(pos["remaining_fraction"]))
    if fraction <= 0:
        return False
    price = float(p.get("priceUsd") or 0)
    entry = float(pos.get("entry_price") or 0)
    if not math.isfinite(price) or not math.isfinite(fraction) or price <= 0 or entry <= 0:
        return False
    principal = float(pos["invested_eur"]) * fraction
    gross_value = principal * (price / entry)
    exit_cost = costs(gross_value)
    net = gross_value - exit_cost
    pnl = net - principal
    s["cash_eur"] += net
    s["realized_pnl_eur"] = float(s.get("realized_pnl_eur", 0)) + pnl
    s["day_realized_pnl_eur"] = float(s.get("day_realized_pnl_eur", 0)) + pnl
    pos["remaining_fraction"] = max(0.0, float(pos["remaining_fraction"]) - fraction)
    if "entry_gross_eur" in pos:
        pos["exit_net_received_eur"] = float(pos.get("exit_net_received_eur",0)) + net
    if reason == "QUICK_TP":
        pos["quick_tp_done"] = True
    if reason in ("TP1", "TP2"):
        pos[reason.lower()+"_done"] = True
    chain_id, token = split_position_key(key)
    append_trade({
        "time": now_iso(), "action": "SELL", "symbol": pos["symbol"], "token": token,
        "price_usd": price, "fraction": round(fraction, 6), "gross_eur": round(net, 4),
        "pnl_eur": round(pnl, 4), "reason": f"{LABELS[chain_id]};chain={chain_id};{reason}",
    })
    log.info("PAPER SELL %s %.0f%% | PnL %.3f EUR | %s", pos["symbol"], fraction * 100, pnl, reason)
    if pos["remaining_fraction"] <= 1e-9:
        del s["positions"][key]
        set_cooldown(s, key, reason)
    save_state(s)
    return True


def opened_minutes(pos):
    raw = str(pos.get("opened_at") or "")
    if not raw:
        return 0.0
    try:
        opened = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if opened.tzinfo is None:
            opened = opened.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - opened.astimezone(timezone.utc)).total_seconds() / 60.0)
    except Exception:
        return 0.0


def position_net_return(pos, price):
    remaining = float(pos["invested_eur"])*float(pos["remaining_fraction"])*price/float(pos["entry_price"])
    hypothetical_exit_net = remaining-costs(remaining)
    total = float(pos.get("exit_net_received_eur",0))+hypothetical_exit_net
    return (total/float(pos["entry_gross_eur"])-1)*100


def manage_positions(s):
    batched = {}
    # Batching pays off only with multiple positions. With one position the exact-pair
    # endpoint is both cheaper and less likely to require a fallback request.
    if CONFIG.get("position_quote_batch_enabled", True) and len(s.get("positions", {})) >= 2 and not STOP.is_set():
        try:
            batched = fetch_open_position_pairs(s)
        except RuntimeError:
            if STOP.is_set():
                return
            raise
        except Exception as exc:
            log.warning("Positions-Batch nicht verfügbar, Exact-Fallback: %s", exc)
    for key in list(s["positions"].keys()):
        if STOP.is_set():
            break
        try:
            chain_id, token = split_position_key(key)
            pos = s["positions"].get(key)
            if not pos:
                continue
            pair_address = pos.get("pair_address")
            if not pair_address:
                # Legacy position: lock it to the currently valid base-token pair once.
                legacy = best_pair(token, chain_id)
                if not legacy:
                    continue
                pos["pair_address"] = legacy.get("pairAddress")
                pair_address = pos["pair_address"]
            p = batched.get(key)
            if not p:
                p = best_pair(token, chain_id, pos.get("symbol"), pair_address=pair_address)
            if not p:
                log.warning("Keine gültige Quote für gespeichertes Pair %s (%s)", pair_address, pos.get("symbol"))
                continue
            price = float(p.get("priceUsd") or 0)
            if price <= 0:
                continue
            pos["quote_received_at"] = time.time()
            pos["current_price"] = price
            pos["price_updated_at"] = now_iso()
            pos["high_price"] = max(float(pos.get("high_price") or pos["entry_price"]), price)
            ret = (price / float(pos["entry_price"]) - 1.0) * 100.0
            pos["change_pct"] = ret
            held = opened_minutes(pos)
            exit_cfg = pos.get("exit_plan", CONFIG)
            record_observation("position_quote", {"key": key, "pair": pair_address, "price": price, "return_pct": ret})

            # No artificial minimum hold. A real stop is allowed immediately,
            # but only on the exact pair stored at entry.
            if ret <= float(exit_cfg.get("stop_loss_pct", -6.0)):
                sell_fraction(s, key, p, pos["remaining_fraction"], "STOP")
                continue

            # New positions have exact entry/partial-exit cashflow accounting.
            guard = exit_cfg.get("profit_guard")
            if guard and "entry_gross_eur" in pos:
                total_return = position_net_return(pos, price)
                pos["peak_net_return_pct"] = max(float(pos.get("peak_net_return_pct",total_return)),total_return)
                peak = pos["peak_net_return_pct"]
                if peak >= guard["protect_arm_net_pct"]:
                    floor = max(guard["protect_floor_net_pct"], peak-guard["protect_giveback_net_pct"])
                    if total_return <= floor:
                        sell_fraction(s,key,p,pos["remaining_fraction"],"NET_PROTECT")
                        continue
                if not pos.get("quick_tp_done") and total_return >= guard["quick_take_net_pct"]:
                    sell_fraction(s,key,p,guard["quick_take_fraction"],"QUICK_TP")
                    if key not in s["positions"]:continue

            if not pos.get("tp1_done") and ret >= float(exit_cfg.get("take_profit_1_pct", 10.0)):
                if sell_fraction(s, key, p, float(exit_cfg.get("tp1_sell_fraction", 0.4)), "TP1"):
                    if key not in s["positions"]:
                        continue
            pos = s["positions"].get(key)
            if not pos:
                continue
            if not pos.get("tp2_done") and ret >= float(exit_cfg.get("take_profit_2_pct", 18.0)):
                if sell_fraction(s, key, p, float(exit_cfg.get("tp2_sell_fraction", 0.3)), "TP2"):
                    if key not in s["positions"]:
                        continue
            pos = s["positions"].get(key)
            if not pos:
                continue

            if pos.get("tp1_done"):
                protect = float(pos["entry_price"]) * (1 + float(exit_cfg.get("post_tp1_protect_pct", 4.0)) / 100.0)
                if price <= protect:
                    sell_fraction(s, key, p, pos["remaining_fraction"], "PROTECT")
                    continue
                trail = float(pos["high_price"]) * (1 - float(exit_cfg.get("trailing_stop_pct", 8.0)) / 100.0)
                if price <= trail:
                    sell_fraction(s, key, p, pos["remaining_fraction"], "TRAIL")
                    continue
            else:
                stale_m = float(exit_cfg.get("stale_exit_minutes", 90))
                stale_net = exit_cfg.get("stale_exit_max_net_return_pct")
                if stale_net is None:
                    # Legacy V8.16 positions keep their frozen raw-price exit plan.
                    stale_due = ret <= float(exit_cfg.get("stale_exit_max_return_pct", 2.0))
                    weak_flow = True
                else:
                    net_now = position_net_return(pos, price)
                    stale_due = net_now <= float(stale_net)
                    weak_flow = True
                    # Never retrofit V8.18 stale-flow rules into positions opened by an
                    # older strategy: missing keys mean the older frozen behaviour.
                    if exit_cfg.get("stale_exit_requires_weak_flow", False):
                        m5_now = metric(p.get("priceChange"), "m5")
                        weak_flow = m5_now <= float(exit_cfg.get("stale_exit_m5_max_pct", 0.0))
                if held >= stale_m and stale_due and weak_flow:
                    sell_fraction(s, key, p, pos["remaining_fraction"], "TIME")
                    continue
                # TIME_FORCE only exists when it was frozen into this position at entry.
                force_m = float(exit_cfg.get("stale_force_minutes", 0) or 0)
                force_net = float(exit_cfg.get("stale_force_max_net_return_pct", 0.0))
                if force_m > 0 and held >= force_m and position_net_return(pos, price) <= force_net:
                    sell_fraction(s, key, p, pos["remaining_fraction"], "TIME_FORCE")
                    continue
            if held >= float(exit_cfg.get("absolute_max_hold_minutes", 240)):
                sell_fraction(s, key, p, pos["remaining_fraction"], "MAXTIME")
        except RuntimeError:
            if STOP.is_set():
                break
            raise
        except Exception as e:
            log.warning("Position %s konnte nicht aktualisiert werden: %s", key, e)


def _mark_reason(reasons, key):
    reasons[key] = reasons.get(key, 0) + 1


def apply_ai_ranking(candidates):
    global AI_STATUS
    if CONFIG["ai_mode"] == "off":
        AI_STATUS={"mode":"off","message":"KI deaktiviert"}
        return candidates
    evaluated=list(candidates);statuses={}
    for chain in ENABLED_CHAINS:
        try:
            learner=LEARNER if chain=="solana" else CHAIN_LEARNERS[chain]
            model=learner.load(TRADES_FILE)
            status=model.status(CONFIG)
            if CONFIG["ai_mode"]=="observe":status["mode"]="observing"
            statuses[chain]=status
            if AI_MODEL_SIGNATURE.get(chain)!=learner.signature:
                # Unit tests must never rewrite the user's persisted learning artefacts.
                if not IS_TEST_PROCESS:
                    atomic_write_json(BASE / f"ai_model_{chain}.json", {"chain":chain,"updated_at":now_iso(),
                        "features":list(FEATURES),"weights":model.weights,"status":status})
                AI_MODEL_SIGNATURE[chain]=learner.signature
            indices=[i for i,x in enumerate(evaluated) if x[3]==chain]
            abstentions=0
            for i in indices:
                score,p,reason,c=evaluated[i]
                assessment=model.assess(features(score,reason))
                prediction=assessment['score'];p["ai_score"]=round(prediction,6)
                p['ai_assessment']=assessment
                abstentions+=int(assessment['abstain'])
                evaluated[i]=(score,p,reason+f",ai_model_score={prediction:.6f},ai_mode={status['mode']},ai_n={model.n}",c)
            status['candidate_abstentions']=abstentions
            if abstentions:
                status['mode']='observing'
                status['message']='Ensemble enthält sich: Widerspruch oder unbekannte Merkmale'
                for i in indices:
                    score,p,reason,c=evaluated[i]
                    evaluated[i]=(score,p,reason.replace('ai_mode=ranking','ai_mode=observing'),c)
            if status["mode"]=="ranking":
                for score in set(evaluated[i][0] for i in indices):
                    slots=[i for i in indices if evaluated[i][0]==score]
                    ranked=sorted((evaluated[i] for i in slots),key=lambda x:x[1]["ai_score"],reverse=True)
                    for i,item in zip(slots,ranked):evaluated[i]=item
        except Exception as exc:
            log.warning("KI %s: %s",chain,exc)
            statuses[chain]={"mode":"error","message":"Feste Regeln bleiben aktiv"}
    active=[LABELS[c] for c,v in statuses.items() if v["mode"]=="ranking"]
    AI_STATUS={"mode":"ranking" if active else "observing",
               "message":"KI getrennt je Chain · Priorisierung: "+(", ".join(active) if active else "noch keine"),
               "closed_trades":sum(x.get("closed_trades",0) for x in statuses.values()),
               "by_chain":statuses}
    return evaluated


def scan_chain_entries(s, chain_id, tokens, pair_map):
    counts = {"found": 0, "liquidity": 0, "volume": 0, "buy_pressure": 0, "momentum": 0, "score": 0}
    reasons = {}
    near = []
    candidates = []
    counts["found"] = len(tokens)
    base_rules = chain_rules(chain_id)
    record_observation("candidate_scan", {"chain": chain_id, "tokens": tokens, "pairs": {
        token: {k: p.get(k) for k in ("pairAddress", "priceUsd", "liquidity", "volume", "priceChange", "txns", "pairCreatedAt")}
        for token, p in pair_map.items() if valid_signal_data(p)}})
    now = time.time()
    qualifying = set()

    for token in tokens:
        key = position_key(chain_id, token)
        if key in s["positions"]:
            continue
        if not token_entry_allowed(s, key):
            _mark_reason(reasons, "token_daily_limit")
            continue
        until = float((s.get("cooldowns") or {}).get(key, 0) or 0)
        if until > now:
            continue
        if key in (s.get("cooldowns") or {}):
            s["cooldowns"].pop(key, None)
        p = pair_map.get(token)
        if not p or not valid_signal_data(p) or time.time()-p.get("_received_epoch",time.time())>float(CONFIG["max_quote_age_seconds"]):
            _mark_reason(reasons, "no_pair")
            continue
        rules = strategy.rules_for(p, base_rules, CONFIG)
        if not strategy.recent_flow_ok(p, CONFIG):
            _mark_reason(reasons, "recent_flow"); continue
        liq, vol, h1chg, m5, buys, sells, ratio, age, turnover = pair_metrics(p)

        min_liq = float(rules.get("min_liquidity_usd", 40000))
        if liq < min_liq:
            _mark_reason(reasons, "liquidity"); near.append((min_liq - liq, p, "low_liquidity")); continue
        counts["liquidity"] += 1

        min_vol = float(rules.get("min_volume_h1_usd", 20000))
        if vol < min_vol:
            _mark_reason(reasons, "volume"); near.append((min_vol - vol, p, "low_volume")); continue
        counts["volume"] += 1

        if buys < float(rules.get("min_h1_buys", 20)) or ratio < float(rules.get("min_buy_sell_ratio", 1.15)):
            _mark_reason(reasons, "buy_pressure"); continue
        max_ratio = rules.get("max_buy_sell_ratio")
        if max_ratio is not None and ratio > float(max_ratio):
            _mark_reason(reasons, "extreme_buy_sell_ratio"); continue
        counts["buy_pressure"] += 1

        if age < float(rules.get("min_pair_age_minutes", 30)):
            _mark_reason(reasons, "too_new"); near.append((float(rules.get("min_pair_age_minutes", 30)) - age, p, "too_new")); continue
        if h1chg < float(rules.get("min_h1_price_change_pct", 2.0)):
            _mark_reason(reasons, "weak_momentum"); continue
        if h1chg > float(rules.get("max_h1_price_change_pct", 45.0)):
            _mark_reason(reasons, "chasing_pump"); continue
        if m5 < float(rules.get("min_m5_price_change_pct", -3.0)):
            _mark_reason(reasons, "weak_m5"); continue
        if m5 > float(rules.get("max_m5_price_change_pct", 10.0)):
            _mark_reason(reasons, "m5_spike"); continue
        if turnover > float(rules.get("max_h1_volume_to_liquidity", 25.0)):
            _mark_reason(reasons, "excess_turnover"); continue
        counts["momentum"] += 1

        score, reason = score_pair(p, chain_id)
        required = int(rules.get("min_score", 6))
        if score < required:
            _mark_reason(reasons, "score"); near.append((required - score, p, "low_score")); continue
        counts["score"] += 1

        qualifying.add(key)
        # Consecutive-scan confirmation: the same pair must still qualify and must not
        # jump or collapse sharply between scans. This avoids one-tick entries.
        rec = SIGNAL_CACHE.get(key)
        pair_addr = str(p.get("pairAddress") or "")
        price = float(p.get("priceUsd") or 0)
        if not rec or rec.get("pair_address") != pair_addr or now - rec.get("time", 0) > float(CONFIG.get("confirmation_max_gap_seconds", 45)):
            SIGNAL_CACHE[key] = {"streak": 1, "time": now, "price": price, "pair_address": pair_addr}
            _mark_reason(reasons, "confirming"); near.append((0, p, "confirming_1")); continue
        move = (price / max(float(rec.get("price") or price), 1e-30) - 1.0) * 100.0
        if move < float(CONFIG.get("confirmation_min_price_move_pct", -4.0)) or move > float(strategy.settings(CONFIG)["high_confirmation_max_move_pct"] if strategy.high(p, CONFIG) else CONFIG.get("confirmation_max_price_move_pct", 4.0)):
            SIGNAL_CACHE[key] = {"streak": 1, "time": now, "price": price, "pair_address": pair_addr}
            _mark_reason(reasons, "confirmation_move"); continue
        streak = int(rec.get("streak", 1)) + 1
        SIGNAL_CACHE[key] = {"streak": streak, "time": now, "price": price, "pair_address": pair_addr}
        if streak < int(CONFIG.get("entry_confirmations", 2)):
            _mark_reason(reasons, "confirming"); continue
        quality = entry_quality_rank(p, chain_id)
        candidates.append((score, p, reason + f",confirm={streak},scanmove={move:.2f}%,quality={quality}", chain_id))

    # Drop stale confirmations so old market states cannot trigger later.
    max_gap = float(CONFIG.get("confirmation_max_gap_seconds", 45)) * 2
    for key in list(SIGNAL_CACHE):
        if key.startswith(chain_id+":") and (key not in qualifying or now - float(SIGNAL_CACHE[key].get("time", 0)) > max_gap):
            SIGNAL_CACHE.pop(key, None)

    return counts, candidates, reasons, near


def collect_market():
    pools = latest_tokens()
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs={chain:pool.submit(fetch_chain_pairs,pools.get(chain,[]),chain) for chain in ENABLED_CHAINS}
        maps={}
        for chain,job in jobs.items():
            try:maps[chain]=job.result()
            except RuntimeError:
                if STOP.is_set():maps[chain]={}
                else:raise
            except Exception as exc:
                log.warning("Chain-Abruf %s fehlgeschlagen: %s",chain,exc);maps[chain]={}
    return pools,maps


def apply_context(candidates, maps, pools, reasons):
    global CONTEXT, LOSS_PAUSES
    now=time.time()
    statistics=read_statistics(TRADES_FILE,float(CONFIG['initial_capital_eur']))
    record_observation('performance_context',{k:statistics.get(k) for k in ('closed','net_pnl','expectancy_eur','profit_factor','win_rate_wilson95','longest_loss_streak','error')})
    CONTEXT={chain:market_context(maps.get(chain,{}),len(pools.get(chain,[])),CONFIG,chain,now)
             for chain in ENABLED_CHAINS}
    try:
        LOSS_PAUSES=loss_pauses(HISTORY.load(TRADES_FILE).closed,CONFIG,now)
    except Exception as exc:
        log.warning("Trade-Historie nicht prüfbar; keine neuen Einstiege: %s",exc)
        reasons['history_error']=reasons.get('history_error',0)+len(candidates)
        CONTEXT['history_error']={"state":"history_error","blocked":True}
        SIGNAL_CACHE.clear()
        return []
    accepted=[]
    for candidate in candidates:
        score,p,reason,chain=candidate
        key=position_key(chain,(p.get('baseToken') or {}).get('address',''))
        rejected=('context_'+CONTEXT[chain]['state'] if CONTEXT[chain]['blocked'] else
                  'loss_pause' if key in LOSS_PAUSES else None)
        record_observation('entry_review',{'chain':chain,'token':key,'accepted':rejected is None,
                           'reason':rejected or 'context_passed','context':CONTEXT[chain]})
        if rejected:
            reasons[rejected]=reasons.get(rejected,0)+1
            SIGNAL_CACHE.pop(key,None)
        else:accepted.append(candidate)
    return accepted


def recheck_entry(previous, chain):
    """Revalidate exact pool immediately before spending paper cash."""
    token=(previous.get("baseToken") or {}).get("address", "")
    try:
        p=best_pair(token, chain, pair_address=previous.get("pairAddress"))
        if not p or not valid_signal_data(p):return None,"recheck_missing"
        if strategy.high(p,CONFIG)!=strategy.high(previous,CONFIG):return None,"recheck_profile_change"
        change=(float(p['priceUsd'])/float(previous['priceUsd'])-1)*100
        if abs(change)>strategy.settings(CONFIG)['entry_recheck_max_move_pct']:return None,"recheck_price_move"
        rules=strategy.rules_for(p,chain_rules(chain),CONFIG)
        liq,vol,h1,m5,buys,sells,ratio,age,turn=pair_metrics(p)
        checks=(liq>=rules['min_liquidity_usd'],vol>=rules['min_volume_h1_usd'],
            buys>=rules['min_h1_buys'],ratio>=rules['min_buy_sell_ratio'],
            (rules.get('max_buy_sell_ratio') is None or ratio<=float(rules['max_buy_sell_ratio'])),age>=rules['min_pair_age_minutes'],
            rules['min_h1_price_change_pct']<=h1<=rules['max_h1_price_change_pct'],
            rules['min_m5_price_change_pct']<=m5<=rules['max_m5_price_change_pct'],
            turn<=rules['max_h1_volume_to_liquidity'],score_pair(p,chain)[0]>=rules['min_score'],
            strategy.recent_flow_ok(p,CONFIG))
        if not all(checks):return None,"recheck_quality"
        p['_received_epoch']=time.time()
        return p,None
    except RuntimeError:
        if STOP.is_set():
            return None,"shutdown"
        raise
    except Exception as exc:
        log.warning("Entry-Neupruefung fehlgeschlagen: %s",exc)
        return None,"recheck_error"


def scan_entries(s, market_data=None):
    global COVERAGE, LAB_STATUS
    pools,maps=collect_market() if market_data is None else market_data
    counts={}; candidates=[]; reasons={}; near=[]; COVERAGE={}
    for chain in ENABLED_CHAINS:
        tokens=pools.get(chain,[])
        c,cs,rs,ns=scan_chain_entries(s,chain,tokens,maps[chain])
        COVERAGE[chain]={"label":LABELS[chain],"known":len(UNIVERSE.tokens.get(chain,{})),
                         "selected":len(tokens),"quoted":len(maps[chain]),"qualified":len(cs)}
        for key,value in c.items():counts[key]=counts.get(key,0)+value
        for key,value in rs.items():reasons[key]=reasons.get(key,0)+value
        candidates.extend(cs);near.extend(ns)
    candidates=apply_context(candidates,maps,pools,reasons)
    candidates.sort(key=lambda x:(entry_quality_rank(x[1], x[3]), x[0], metric(x[1].get("liquidity"),"usd")), reverse=True)
    # Solana-trained AI remains observing for other chains until chain-specific evidence exists.
    candidates=apply_ai_ranking(candidates)
    if LAB is not None:
        try:
            LAB.advance(maps,candidates,costs(1))
            LAB_STATUS=LAB.report()
        except Exception as exc:
            log.warning("Strategielabor pausiert: %s",exc)
            LAB_STATUS={"mode":"error","error":type(exc).__name__}
    near.sort(key=lambda x:x[0])
    opened=0
    for score,p,reason,chain in candidates:
        if opened>=int(CONFIG["max_new_positions_per_scan"]) or not can_open(s):break
        fresh, rejection = recheck_entry(p, chain)
        if fresh is None:
            _mark_reason(reasons, rejection)
            SIGNAL_CACHE.pop(position_key(chain,(p.get("baseToken") or {}).get("address","")),None)
            record_observation("entry_rejected", {"chain":chain,"pair":p.get("pairAddress"),"reason":rejection})
            continue
        fresh_score, fresh_reason = score_pair(fresh, chain)
        if open_position(s,fresh,chain,fresh_score,fresh_reason+";fresh_recheck=passed"):opened+=1
    return counts,candidates,reasons,near[:5]


def portfolio_value(s):
    total = float(s.get("cash_eur", 0))
    exit_rate = (float(CONFIG.get("paper_slippage_pct", 0)) + float(CONFIG.get("paper_fee_pct", 0))) / 100.0
    for pos in s.get("positions", {}).values():
        entry = float(pos.get("entry_price") or 0)
        price = float(pos.get("current_price") or entry or 0)
        if entry <= 0:
            continue
        gross_value = float(pos.get("invested_eur", 0)) * float(pos.get("remaining_fraction", 1)) * (price / entry)
        total += gross_value * (1.0 - exit_rate)
    return total


def snapshot_payload(s, counts, candidates, reasons, near):
    best = None
    if candidates:
        score, p, reason, chain_id = candidates[0]
        liq, vol, h1chg, m5, buys, sells, ratio, age, turnover = pair_metrics(p)
        best = {
            "symbol": (p.get("baseToken") or {}).get("symbol", "?"), "score": score, "ai_score": p.get("ai_score"),
            "chain": LABELS[chain_id], "change_h1": h1chg, "m5": m5, "liq": liq,
            "vol_h1": vol, "ratio": ratio, "age": age, "turnover": turnover,
            "address": (p.get("baseToken") or {}).get("address", ""),
        }
    return {
        "strategy_database": dict(LAB_STATUS),
        "context": dict(CONTEXT), "loss_pauses": dict(LOSS_PAUSES),
        "discovery": UNIVERSE.status(CONFIG),
        "coverage": dict(COVERAGE), "discovery_errors": list(UNIVERSE.errors),
        "ai": dict(AI_STATUS),
        "updated_at_epoch": time.time(), "feed_errors": recent_feed_errors(), "api": dict(API_STATUS),
        "counts": counts, "best": best, "reasons": reasons, "near": near,
        "portfolio_value": portfolio_value(s), "time": datetime.now().astimezone().strftime("%H:%M:%S"),
        "status": ("Einstiege gesperrt · Risikolimit · PAPER only" if s.get("daily_halt") or s.get("drawdown_halt") else f"Multi-Chain {CONFIG.get('version')} · PAPER only · keine Gewinngarantie"),
        "daily_halt": bool(s.get("daily_halt")), "drawdown_halt": bool(s.get("drawdown_halt")),
        "version": CONFIG.get("version", "V8.0-paper"),
    }


def acquire_process_lock():
    handle = LOCK_FILE.open("a+")
    try:
        import fcntl
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            handle.close()
            raise RuntimeError("Diese Bot-Instanz läuft bereits")
    except ImportError:
        # The Android foreground service is the single-process supervisor.
        pass
    handle.seek(0); handle.truncate(); handle.write(str(os.getpid())); handle.flush()
    return handle


def initialize_lab():
    global LAB, LAB_STATUS
    # Ordinary unit tests must not seed the persistent forward-only research DB
    # with synthetic fixtures. Dedicated lab tests use a temporary database.
    if IS_TEST_PROCESS:
        LAB=None
        LAB_STATUS={"mode":"test_disabled","note":"Vorwärts-Labor in Unit-Tests deaktiviert."}
        return
    try:
        LAB=FocusedStrategyLab(BASE / "strategies_v818.sqlite3", CONFIG)
        LAB_STATUS=LAB.report()
    except Exception as exc:
        LAB=None
        LAB_STATUS={"mode":"error","error":type(exc).__name__,"note":"Labor deaktiviert; bestehende Datei unverändert. Hauptstrategie läuft unabhängig weiter."}
        log.exception("Optionales Strategielabor nicht verfügbar")


def main():
    global LAB
    lock_handle = acquire_process_lock()
    STOP.clear()
    scanner_pool = None
    old_signals = {}
    if threading.current_thread() is threading.main_thread():
        for sig in (signal.SIGINT, signal.SIGTERM):
            old_signals[sig] = signal.signal(sig, lambda *_: STOP.set())
    try:
        validate_config()
        initialize_lab()
        s = load_state()
        update_risk(s)
        save_state(s)
        log.info("Paper Bot %s gestartet. KEIN Echtgeld. Multi-Chain | Positionen=%ss | Markt=%ss | Wert=%.2f EUR",
                 CONFIG.get("version"), CONFIG["scan_interval_seconds"],
                 CONFIG.get("market_scan_interval_seconds", CONFIG["scan_interval_seconds"]), portfolio_value(s))
        scanner_pool = ThreadPoolExecutor(max_workers=1)
        pending_market = None
        market_started = 0
        market_scan_at = 0
        next_market_scan_at = 0.0
        market_interval = float(CONFIG.get("market_scan_interval_seconds", CONFIG["scan_interval_seconds"]))
        last_scan = ({}, [], {}, [])
        while not STOP.is_set():
            try:
                if s.get("day") != today_utc():
                    s["day"] = today_utc(); s["day_realized_pnl_eur"] = 0.0; s["trades_today"] = 0
                    s["token_entries_today"] = {}
                    s["day_start_equity_eur"] = portfolio_value(s); s["daily_halt"] = False
                manage_positions(s)
                update_risk(s)
                save_state(s)
                if STOP.is_set():
                    break
                if pending_market is None and time.time() >= next_market_scan_at:
                    market_started = time.time()
                    next_market_scan_at = market_started + market_interval
                    pending_market = scanner_pool.submit(collect_market)
                if pending_market is not None and pending_market.done():
                    completed = pending_market
                    pending_market = None
                    market_data = completed.result()
                    last_scan = scan_entries(s, market_data)
                    market_scan_at = time.time()
                    pending_market = None
                counts, candidates, reasons, near = last_scan
                save_state(s)
                snap = snapshot_payload(s, counts, candidates, reasons, near)
                snap["heartbeat_epoch"] = time.time()
                snap["scan_running"] = pending_market is not None
                snap["scan_elapsed_seconds"] = max(0,time.time()-market_started) if pending_market is not None else 0
                snap["next_market_scan_in_seconds"] = max(0, next_market_scan_at-time.time()) if pending_market is None else 0
                snap["updated_at_epoch"] = market_scan_at
                # Human console/dashboard status uses the device local timezone.
                # Ledger timestamps remain ISO/UTC for unambiguous statistics.
                snap["time"] = datetime.fromtimestamp(market_scan_at).astimezone().strftime("%H:%M:%S") if market_scan_at else "—"
                atomic_write_json(SNAPSHOT_FILE, snap)
                render(s, {"config": CONFIG, **snap})
            except KeyboardInterrupt:
                save_state(s); log.info("Beendet."); break
            except Exception as e:
                log.exception("Loop-Fehler: %s", e)
                save_state(s)
            try:
                time.sleep(float(CONFIG.get("scan_interval_seconds", 10)))
            except KeyboardInterrupt:
                save_state(s); log.info("Beendet."); break
    finally:
        STOP.set()
        # Prevent new pool requests before joining any producers.
        UNIVERSE.stop.set()
        if scanner_pool is not None:
            scanner_pool.shutdown(wait=True, cancel_futures=True)
        UNIVERSE.close()
        for sig, handler in old_signals.items():
            signal.signal(sig, handler)
        if lock_handle is not None:
            lock_handle.close()
    return None


if __name__ == "__main__":
    main()
