import re
LABELS={'solana':'Solana','ethereum':'Ethereum','base':'Base','bsc':'BNB Chain',
        'arbitrum':'Arbitrum','polygon':'Polygon','avalanche':'Avalanche','optimism':'Optimism'}
def normalize(chain,token):
    token=str(token)
    return token.lower() if chain!='solana' and token.startswith('0x') else token

def trade_chain(row):
    reason=str(row.get('reason',''))
    m=re.search(r'(?:^|[;,])chain=([a-z0-9]+)',reason)
    if m and m.group(1) in LABELS:return m.group(1)
    first=reason.split(';')[0].strip().lower()
    for chain,label in LABELS.items():
        if first in (chain,label.lower()):return chain
    return 'solana'
