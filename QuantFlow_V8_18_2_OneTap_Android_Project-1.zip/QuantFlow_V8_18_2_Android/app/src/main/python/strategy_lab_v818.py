"""Focused forward-only shadow lab for V8.18.

This module never opens wallet/paper-wallet positions.  It reuses already-fetched
DEX Screener snapshots to compare a small, fixed family of hypotheses.  Keeping
the family small is deliberate: the previous 10k+ catalogue spread observations
so thinly that no variant accumulated a useful validation sample.
"""
from __future__ import annotations
import itertools, json, math, sqlite3, time
from contextlib import contextmanager
from pathlib import Path


def _metric(d, k, default=0.0):
    try:
        x=float((d or {}).get(k, default) or default)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default


def _norm(chain, token):
    token=str(token or "")
    return token if chain=="solana" else token.lower()


def _age_minutes(p, now):
    try:return max(0.0,(now*1000-float(p.get("pairCreatedAt") or 0))/60000)
    except (TypeError,ValueError):return 0.0


def _pair_metrics(p, now):
    tx=(p.get("txns") or {}).get("h1") or {}
    liq=_metric(p.get("liquidity"),"usd")
    vol=_metric(p.get("volume"),"h1")
    h1=_metric(p.get("priceChange"),"h1")
    m5=_metric(p.get("priceChange"),"m5")
    buys=float(tx.get("buys") or 0); sells=float(tx.get("sells") or 0)
    return dict(liq=liq,vol=vol,h1=h1,m5=m5,buys=buys,sells=sells,
                ratio=buys/max(sells,1.0),age=_age_minutes(p,now),turn=vol/max(liq,1.0))


def _same_pair(chain, a, b):
    a=str(a or "");b=str(b or "")
    return a==b if chain=="solana" else a.lower()==b.lower()


def _pf(vals):
    wins=sum(x for x in vals if x>0); losses=-sum(x for x in vals if x<0)
    return wins/losses if losses else None


class FocusedStrategyLab:
    def __init__(self,path:Path,cfg:dict):
        self.path=Path(path);self.cfg=cfg;self.confirm={}
        self.lab_cfg=cfg.get("research_lab_v818",{})
        self.max_active=int(self.lab_cfg.get("max_active_per_variant",2))
        with self.connect() as c:
            c.executescript('''
CREATE TABLE IF NOT EXISTS variants(id INTEGER PRIMARY KEY, parameters TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS shadow(id INTEGER PRIMARY KEY, variant INTEGER NOT NULL, chain TEXT NOT NULL,
 token TEXT NOT NULL, pair TEXT NOT NULL, entry REAL NOT NULL, opened REAL NOT NULL,
 last_quote REAL NOT NULL, rate REAL NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS v818_shadow_unique ON shadow(variant,chain,token);
CREATE TABLE IF NOT EXISTS outcomes(id INTEGER PRIMARY KEY, variant INTEGER NOT NULL, chain TEXT NOT NULL,
 token TEXT NOT NULL, opened REAL NOT NULL, closed REAL NOT NULL, net_return REAL NOT NULL,
 reason TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v818_outcome_variant ON outcomes(variant,id);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
''')
            if c.execute('SELECT COUNT(*) FROM variants').fetchone()[0]==0:
                rows=[];ident=1
                # 24 deliberately coarse hypotheses.  The active strategy is inside
                # this grid, but the lab is never allowed to auto-promote a winner.
                for m5,ratio,h1,stop in itertools.product((0.8,1.0,1.2),(2.5,5.0),(1.0,3.0),(5.0,6.0)):
                    params={"min_m5":m5,"max_ratio":ratio,"min_h1":h1,"stop_pct":stop,
                            "target_net_pct":4.0,"stale_minutes":120.0,"stale_net_pct":-1.0,
                            "max_hold_minutes":180.0}
                    rows.append((ident,json.dumps(params,sort_keys=True)));ident+=1
                c.executemany('INSERT INTO variants(id,parameters) VALUES (?,?)',rows)
            elif c.execute('SELECT COUNT(*) FROM variants').fetchone()[0]!=24:
                raise ValueError('V8.18-Forschungskatalog hat unerwartete Größe')

    @contextmanager
    def connect(self):
        c=sqlite3.connect(self.path,timeout=3);c.row_factory=sqlite3.Row
        try:
            with c:yield c
        finally:c.close()

    def _qualifies(self,p,params,now):
        try:
            price=float(p.get("priceUsd") or 0)
            if not math.isfinite(price) or price<=0:return False
            m=_pair_metrics(p,now)
            return (m['liq']>=100000 and m['vol']>=20000 and m['buys']>=20 and
                    1.25<=m['ratio']<=params['max_ratio'] and m['age']>=180 and
                    params['min_h1']<=m['h1']<=30 and params['min_m5']<=m['m5']<=5 and
                    m['turn']<=8 and bool(p.get('pairAddress')))
        except (TypeError,ValueError):return False

    def _candidate_rank(self,p,now):
        m=_pair_metrics(p,now)
        # Stable deterministic preference, not learned from outcomes.
        return (min(m['m5'],3.0), min(m['h1'],15.0), -abs(m['ratio']-1.7), m['liq'])

    def advance(self,maps,candidates,rate,now=None):
        del candidates  # intentionally evaluate the raw fetched maps, not only main-strategy survivors
        now=time.time() if now is None else float(now)
        with self.connect() as c:
            variants=[(r['id'],json.loads(r['parameters'])) for r in c.execute('SELECT * FROM variants ORDER BY id')]
            # 1) Mark/close existing forward shadows from snapshots already fetched by the bot.
            for row in c.execute('SELECT * FROM shadow').fetchall():
                p=maps.get(row['chain'],{}).get(row['token'])
                if not p or not _same_pair(row['chain'],p.get('pairAddress'),row['pair']):
                    continue
                try:price=float(p.get('priceUsd') or 0)
                except (TypeError,ValueError):continue
                if not math.isfinite(price) or price<=0:continue
                params=dict(variants)[row['variant']]
                raw=(price/row['entry']-1)*100
                net=((1-row['rate'])**2*(price/row['entry'])-1)*100
                held=(now-row['opened'])/60
                reason=None
                if raw<=-params['stop_pct']:reason='STOP'
                elif net>=params['target_net_pct']:reason='TARGET'
                elif held>=params['stale_minutes'] and net<=params['stale_net_pct']:reason='TIME'
                elif held>=params['max_hold_minutes']:reason='MAXTIME'
                if reason:
                    c.execute('INSERT INTO outcomes(variant,chain,token,opened,closed,net_return,reason) VALUES (?,?,?,?,?,?,?)',
                              (row['variant'],row['chain'],row['token'],row['opened'],now,net,reason))
                    c.execute('DELETE FROM shadow WHERE id=?',(row['id'],))
                else:c.execute('UPDATE shadow SET last_quote=? WHERE id=?',(now,row['id']))
            # Remove experiments that stopped receiving any sampled quote; do not invent PnL.
            expired=c.execute('SELECT COUNT(*) FROM shadow WHERE ?-last_quote>21600',(now,)).fetchone()[0]
            if expired:
                c.execute('DELETE FROM shadow WHERE ?-last_quote>21600',(now,))
                old=c.execute("SELECT value FROM meta WHERE key='expired'").fetchone()
                total=(int(old[0]) if old else 0)+expired
                c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('expired',?)",(str(total),))

            active_counts={r['variant']:r['n'] for r in c.execute('SELECT variant,COUNT(*) n FROM shadow GROUP BY variant')}
            # 2) Each fixed variant gets its own 3-snapshot confirmation before a new shadow opens.
            for vid,params in variants:
                if active_counts.get(vid,0)>=self.max_active:continue
                choices=[]
                for chain,pair_map in maps.items():
                    for token,p in pair_map.items():
                        token=_norm(chain,token)
                        if not self._qualifies(p,params,now):
                            self.confirm.pop((vid,chain,token),None);continue
                        pair=str(p.get('pairAddress') or '');price=float(p.get('priceUsd') or 0)
                        ck=(vid,chain,token);old=self.confirm.get(ck)
                        if not old or not _same_pair(chain,old['pair'],pair) or now-old['time']>180:
                            self.confirm[ck]={'n':1,'time':now,'price':price,'pair':pair};continue
                        move=(price/old['price']-1)*100
                        if not -0.35<=move<=2.5:
                            self.confirm[ck]={'n':1,'time':now,'price':price,'pair':pair};continue
                        rec={'n':old['n']+1,'time':now,'price':price,'pair':pair};self.confirm[ck]=rec
                        if rec['n']>=3:choices.append((self._candidate_rank(p,now),chain,token,p))
                if not choices:continue
                choices.sort(reverse=True,key=lambda x:x[0])
                for _,chain,token,p in choices:
                    if active_counts.get(vid,0)>=self.max_active:break
                    if c.execute('SELECT 1 FROM shadow WHERE variant=? AND chain=? AND token=?',(vid,chain,token)).fetchone():continue
                    c.execute('INSERT INTO shadow(variant,chain,token,pair,entry,opened,last_quote,rate) VALUES (?,?,?,?,?,?,?,?)',
                              (vid,chain,token,p['pairAddress'],float(p['priceUsd']),now,now,float(rate)))
                    active_counts[vid]=active_counts.get(vid,0)+1
                    self.confirm.pop((vid,chain,token),None)

    def report(self):
        minimum=int(self.lab_cfg.get('min_outcomes_for_validation',20));tail=int(self.lab_cfg.get('validation_tail',8))
        with self.connect() as c:
            variants={r['id']:json.loads(r['parameters']) for r in c.execute('SELECT * FROM variants')}
            rows=[]
            for vid,params in variants.items():
                vals=[float(r[0]) for r in c.execute('SELECT net_return FROM outcomes WHERE variant=? ORDER BY id',(vid,))]
                if not vals:continue
                validation=vals[-tail:] if len(vals)>=minimum else []
                train=vals[:-tail] if validation else vals
                rows.append({'id':vid,'parameters':params,'n':len(vals),'train_n':len(train),
                             'train_mean_pct':sum(train)/len(train),'train_win_rate':sum(v>0 for v in train)/len(train),
                             'train_profit_factor':_pf(train),'validation_n':len(validation),
                             'validation_mean_pct':sum(validation)/len(validation) if validation else None,
                             'validation_win_rate':sum(v>0 for v in validation)/len(validation) if validation else None,
                             'validation_profit_factor':_pf(validation) if validation else None,
                             'status':'forward_validation' if validation else 'collecting'})
            eligible=[r for r in rows if r['validation_n']]
            eligible.sort(key=lambda r:(r['validation_mean_pct'],r['validation_profit_factor'] or -1),reverse=True)
            expired=c.execute("SELECT value FROM meta WHERE key='expired'").fetchone()
            return {'mode':'focused_shadow_only','variants':len(variants),
                    'shadow_open':c.execute('SELECT COUNT(*) FROM shadow').fetchone()[0],
                    'shadow_closed':c.execute('SELECT COUNT(*) FROM outcomes').fetchone()[0],
                    'expired_without_price':int(expired[0]) if expired else 0,
                    'validated_variants':len(eligible),'top':eligible[:5],
                    'note':'24 feste Vorwärts-Hypothesen; keine automatische Übernahme, keine Orders.'}
