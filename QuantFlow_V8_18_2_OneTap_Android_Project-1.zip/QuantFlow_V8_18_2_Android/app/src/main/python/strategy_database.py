"""Growing hypotheses and bounded, forward-only shadow experiments. No orders."""
import sqlite3,json,itertools,time,math,random
from pathlib import Path
from contextlib import contextmanager

class StrategyDatabase:
 def __init__(self,path):
  self.path=Path(path)
  with self.connect() as c:
   c.executescript('''CREATE TABLE IF NOT EXISTS variants(id INTEGER PRIMARY KEY, parameters TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value INTEGER);
CREATE TABLE IF NOT EXISTS lineage(variant INTEGER PRIMARY KEY,parent INTEGER,generation INTEGER,created REAL,method TEXT);
CREATE TABLE IF NOT EXISTS shadow(id INTEGER PRIMARY KEY,variant INTEGER,chain TEXT,token TEXT,pair TEXT,entry REAL,opened REAL,rate REAL,stop REAL,target REAL,last_quote REAL);
CREATE TABLE IF NOT EXISTS outcomes(id INTEGER PRIMARY KEY,variant INTEGER,chain TEXT,token TEXT,opened REAL,closed REAL,net_return REAL,reason TEXT);
CREATE INDEX IF NOT EXISTS outcome_variant ON outcomes(variant);
CREATE UNIQUE INDEX IF NOT EXISTS one_shadow_per_variant ON shadow(variant);''')
   count=c.execute('SELECT COUNT(*) FROM variants').fetchone()[0]
   if count==0:
    rows=[]
    grid=itertools.product([100000,150000,250000,400000,600000],[20000,40000,60000,100000,150000],[2,3,4,6,8],[20,30,45,60],[4,6,8,10,12],[1.2,1.5,2,2.5])
    for ident,values in enumerate(grid,1):
     p=dict(zip(('min_liquidity','min_volume_h1','max_m5','max_h1','stop_pct','net_reward_risk'),values));rows.append((ident,json.dumps(p,sort_keys=True)))
    c.executemany('INSERT INTO variants VALUES (?,?)',rows)
   elif count<10000:raise ValueError('Strategiekatalog unvollständig; keine automatische Überschreibung')
 @contextmanager
 def connect(self):
  c=sqlite3.connect(self.path,timeout=3);c.row_factory=sqlite3.Row
  try:
   with c:yield c
  finally:c.close()
 def advance(self,maps,candidates,rate,now=None):
  now=time.time() if now is None else now
  self.grow(now)
  with self.connect() as c:
   for row in c.execute('SELECT * FROM shadow').fetchall():
    p=maps.get(row['chain'],{}).get(row['token'])
    if not p or p.get('pairAddress')!=row['pair'] or now-float(p.get('_received_epoch',0))>60:continue
    price=float(p['priceUsd']);move=(price/row['entry']-1)*100
    if not math.isfinite(price) or price<=0:continue
    reason='STOP' if move<=-row['stop'] else 'TARGET' if move>=row['target'] else 'TIME' if now-row['opened']>=7200 else None
    if reason:
     net=((1-row['rate'])**2*(price/row['entry'])-1)*100
     c.execute('INSERT INTO outcomes(variant,chain,token,opened,closed,net_return,reason) VALUES (?,?,?,?,?,?,?)',(row['variant'],row['chain'],row['token'],row['opened'],now,net,reason))
     c.execute('DELETE FROM shadow WHERE id=?',(row['id'],))
    else:c.execute('UPDATE shadow SET last_quote=? WHERE id=?',(now,row['id']))
   # Stale experiments are removed without fabricated PnL. Report separately.
   n=c.execute('SELECT COUNT(*) FROM shadow WHERE ?-last_quote>86400',(now,)).fetchone()[0]
   if n:
    c.execute("INSERT INTO meta VALUES ('expired',?) ON CONFLICT(key) DO UPDATE SET value=value+excluded.value",(n,));c.execute('DELETE FROM shadow WHERE ?-last_quote>86400',(now,))
   free=max(0,96-c.execute('SELECT COUNT(*) FROM shadow').fetchone()[0]);added=0
   cursor=c.execute("SELECT value FROM meta WHERE key='cursor'").fetchone();cursor=cursor[0] if cursor else 0
   variants=c.execute('SELECT * FROM variants WHERE id>? ORDER BY id LIMIT 256',(cursor,)).fetchall()
   last_visited=cursor
   for v in variants:
    if added>=min(4,free):break
    last_visited=v["id"]
    if c.execute('SELECT 1 FROM shadow WHERE variant=?',(v['id'],)).fetchone():continue
    params=json.loads(v['parameters'])
    for _,p,_,chain in candidates[:6]:
     if now-float(p.get('_received_epoch',0))>60:continue
     liq=float((p.get('liquidity')or{}).get('usd',0));vol=float((p.get('volume')or{}).get('h1',0));h1=float(p['priceChange']['h1']);m5=float(p['priceChange']['m5'])
     if not(liq>=params['min_liquidity'] and vol>=params['min_volume_h1'] and 1<=h1<=params['max_h1'] and 0<=m5<=params['max_m5']):continue
     retained=(1-rate)**2;loss=1-retained*(1-params['stop_pct']/100);target=100*((1+params['net_reward_risk']*loss)/retained-1)
     c.execute('INSERT INTO shadow(variant,chain,token,pair,entry,opened,rate,stop,target,last_quote) VALUES (?,?,?,?,?,?,?,?,?,?)',(v['id'],chain,(p['baseToken']['address'] if chain=='solana' else p['baseToken']['address'].lower()),p['pairAddress'],float(p['priceUsd']),now,rate,params['stop_pct'],target,now));added+=1;break
   c.execute("INSERT OR REPLACE INTO meta VALUES ('cursor',?)",(last_visited if last_visited<c.execute("SELECT MAX(id) FROM variants").fetchone()[0] else 0,))
 def grow(self,now=None):
  now=time.time() if now is None else now
  with self.connect() as c:
   last=c.execute("SELECT value FROM meta WHERE key='last_growth'").fetchone()
   if last and now-last[0]<3600:return 0
  # Prefer parents with observed training AND later comparison results.
  parents=[r['id'] for r in self.report()['top'] if r['n']>=50 and r['posterior_net_score_pct']>0 and (r['validation_mean_pct'] or 0)>0]
  rng=random.Random(int(now));added=0
  bounds={'min_liquidity':(100000,1000000,1000),'min_volume_h1':(20000,500000,1000),'max_m5':(1,8,.5),'max_h1':(10,60,1),'stop_pct':(3,12,.5),'net_reward_risk':(1.2,3,.1)}
  with self.connect() as c:
   # Recheck inside write transaction to avoid repeated growth on a restart.
   c.execute('BEGIN IMMEDIATE')
   last=c.execute("SELECT value FROM meta WHERE key='last_growth'").fetchone()
   if last and now-last[0]<3600:return 0
   for attempt in range(512):
    if added>=32:break
    parent=rng.choice(parents) if parents and rng.random()<.75 else rng.randint(1,10000)
    row=c.execute('SELECT parameters FROM variants WHERE id=?',(parent,)).fetchone()
    if not row:continue
    params=json.loads(row[0]);field=rng.choice(list(bounds));lo,hi,step=bounds[field]
    params[field]=round(max(lo,min(hi,round(params[field]*rng.choice([.8,.9,1.1,1.2])/step)*step)),4)
    blob=json.dumps(params,sort_keys=True)
    # Canonical numeric types avoid treating 6 and 6.0 as different rules.
    blob=json.dumps({k:int(v) if float(v).is_integer() else v for k,v in params.items()},sort_keys=True)
    old=c.execute('SELECT id FROM variants WHERE parameters=?',(blob,)).fetchone()
    if old:continue
    cur=c.execute('INSERT INTO variants(parameters) VALUES (?)',(blob,))
    generation=c.execute('SELECT generation FROM lineage WHERE variant=?',(parent,)).fetchone()
    c.execute('INSERT INTO lineage VALUES (?,?,?,?,?)',(cur.lastrowid,parent,1+(generation[0] if generation else 0),now,'learned_parent_mutation' if parent in parents else 'exploration'))
    added+=1
   c.execute("INSERT OR REPLACE INTO meta VALUES ('last_growth',?)",(int(now),))
  return added
 def report(self):
  with self.connect() as c:
   count=c.execute('SELECT COUNT(*) FROM outcomes').fetchone()[0];active=c.execute('SELECT COUNT(*) FROM shadow').fetchone()[0]
   groups=c.execute('SELECT variant,chain,COUNT(*) n FROM outcomes GROUP BY variant,chain HAVING n>=5 ORDER BY n DESC LIMIT 100').fetchall();ranks=[]
   for g in groups:
    values=[r[0] for r in c.execute('SELECT net_return FROM outcomes WHERE variant=? AND chain=? ORDER BY id',(g['variant'],g['chain']))];n=len(values)
    train=values[:-20] if n>=50 else values;validation=values[-20:] if n>=50 else []
    wins=[v for v in train if v>0];losses=[v for v in train if v<=0];prob=(len(wins)+1)/(len(train)+2)
    # Beta(1,1) posterior for win frequency, NOT a calibrated next-trade guarantee.
    score=prob*(sum(wins)/len(wins) if wins else 0)+(1-prob)*(sum(losses)/len(losses) if losses else 0)
    ranks.append({'id':g['variant'],'chain':g['chain'],'n':n,'posterior_win_frequency':prob,'posterior_net_score_pct':score,'validation_n':len(validation),'validation_mean_pct':sum(validation)/len(validation) if validation else None,'status':'research_only'})
   ranks.sort(key=lambda r:r['posterior_net_score_pct'],reverse=True)
   expired=c.execute("SELECT value FROM meta WHERE key='expired'").fetchone()
   return {'variants':c.execute('SELECT COUNT(*) FROM variants').fetchone()[0],'generated':c.execute('SELECT COUNT(*) FROM lineage').fetchone()[0],'shadow_open':active,'shadow_closed':count,'expired_without_price':expired[0] if expired else 0,'mode':'shadow_only','top':ranks[:10], 'note':'Bayes-Bewertung aus Vorwärts-Paper-Tests; keine automatische Übernahme. Ergebnisse sind durch die Scanner-Auswahl vorselektiert.'}

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--db',type=Path,default=Path(__file__).with_name('strategies.sqlite3'));a=p.parse_args();print(json.dumps(StrategyDatabase(a.db).report(),indent=2,ensure_ascii=False))
