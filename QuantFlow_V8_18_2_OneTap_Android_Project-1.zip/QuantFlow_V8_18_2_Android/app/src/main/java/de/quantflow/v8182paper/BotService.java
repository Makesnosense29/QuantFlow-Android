package de.quantflow.v8182paper;

import android.app.*;
import android.content.*;
import android.os.*;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.*;

public class BotService extends Service {
    public static final String CHANNEL_ID = "quantflow_bot";
    public static volatile boolean running = false;
    private PowerManager.WakeLock wakeLock;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1001, notification("V8.18.2-forward startet …"));
        if (!running) {
            running = true;
            acquireWakeLock();
            worker = new Thread(() -> {
                try {
                    seedRuntimeFiles();
                    if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                    PyObject bridge = Python.getInstance().getModule("android_bridge");
                    bridge.callAttr("start", getFilesDir().getAbsolutePath());
                    updateNotification("V8.18.2-forward läuft · PAPER only");
                } catch (Throwable t) {
                    writeServiceError(t);
                    updateNotification("Startfehler – App öffnen");
                    running = false;
                }
            }, "quantflow-python-start");
            worker.start();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        stopPython();
        releaseWakeLock();
        running = false;
        super.onDestroy();
    }

    private void stopPython() {
        new Thread(() -> {
            try {
                if (Python.isStarted()) Python.getInstance().getModule("android_bridge").callAttr("stop");
            } catch (Throwable ignored) {}
        }, "quantflow-python-stop").start();
    }

    private void seedRuntimeFiles() throws IOException {
        copyAssetTree("bot_seed", getFilesDir());
    }

    private void copyAssetTree(String assetPath, File destDir) throws IOException {
        String[] children = getAssets().list(assetPath);
        if (children == null || children.length == 0) {
            File out = new File(destDir, new File(assetPath).getName());
            boolean immutable = out.getName().equals("config.json") || out.getName().endsWith(".html") ||
                    out.getName().endsWith(".js") || out.getName().endsWith(".css");
            if (!out.exists() || immutable) {
                try (InputStream in = getAssets().open(assetPath); OutputStream os = new FileOutputStream(out, false)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
            return;
        }
        if (!destDir.exists()) destDir.mkdirs();
        for (String child : children) copyAssetTree(assetPath + "/" + child, destDir);
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "QuantFlow::PaperBot");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "QuantFlow Paper Bot", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Hält den lokalen Paper-Bot im Vordergrund aktiv.");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(de.quantflow.v8182paper.R.drawable.ic_bot)
                .setContentTitle("QuantFlow Paper")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private void updateNotification(String text) {
        getSystemService(NotificationManager.class).notify(1001, notification(text));
    }

    private void writeServiceError(Throwable t) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(new File(getFilesDir(), "android_service.log"), true))) {
            pw.println(new java.util.Date() + " | " + t);
            t.printStackTrace(pw);
        } catch (IOException ignored) {}
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
