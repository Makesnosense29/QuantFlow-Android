package de.quantflow.v8182paper;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String DASHBOARD = "http://127.0.0.1:8766/";
    private WebView web;
    private FrameLayout loading;
    private TextView loadingText;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int healthAttempts = 0;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 12, 18));
        getWindow().setNavigationBarColor(Color.rgb(9, 12, 18));
        buildUi();
        requestNotifications();
        startBot();
        waitForDashboard();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 12, 18));

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        web.setBackgroundColor(Color.rgb(9, 12, 18));
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("127.0.0.1".equals(uri.getHost()) || "localhost".equals(uri.getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loading.setVisibility(View.VISIBLE);
                    loadingText.setText("QuantFlow verbindet sich …");
                }
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button more = new Button(this);
        more.setText("⋮");
        more.setTextSize(24);
        more.setTextColor(Color.WHITE);
        more.setBackgroundColor(Color.TRANSPARENT);
        more.setPadding(0, 0, 0, 0);
        more.setOnClickListener(v -> showMaintenanceMenu(more));
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(64, 64, Gravity.TOP | Gravity.END);
        mp.topMargin = 4; mp.rightMargin = 4;
        root.addView(more, mp);

        loading = new FrameLayout(this);
        loading.setBackgroundColor(Color.rgb(9, 12, 18));
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(36, 36, 36, 36);

        TextView title = new TextView(this);
        title.setText("QuantFlow");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        center.addView(title);

        TextView version = new TextView(this);
        version.setText("V8.18.2-forward · PAPER only");
        version.setTextColor(Color.rgb(145, 160, 180));
        version.setTextSize(14);
        version.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vp.topMargin = 8;
        center.addView(version, vp);

        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(56, 56);
        pp.topMargin = 30;
        center.addView(progress, pp);

        loadingText = new TextView(this);
        loadingText.setText("Bot wird gestartet …");
        loadingText.setTextColor(Color.LTGRAY);
        loadingText.setTextSize(14);
        loadingText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 18;
        center.addView(loadingText, lp);

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        loading.addView(center, cp);
        root.addView(loading, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void startBot() {
        Intent i = new Intent(this, BotService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void waitForDashboard() {
        healthAttempts = 0;
        handler.post(this::probeDashboard);
    }

    private void probeDashboard() {
        new Thread(() -> {
            boolean ok = false;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(DASHBOARD).openConnection();
                c.setConnectTimeout(700);
                c.setReadTimeout(700);
                c.setUseCaches(false);
                int code = c.getResponseCode();
                ok = code >= 200 && code < 500;
                c.disconnect();
            } catch (Exception ignored) {}
            final boolean ready = ok;
            runOnUiThread(() -> {
                if (ready) {
                    loadingText.setText("Dashboard wird geöffnet …");
                    web.loadUrl(DASHBOARD);
                } else {
                    healthAttempts++;
                    if (healthAttempts > 25) loadingText.setText("Bot startet noch … bitte einen Moment warten");
                    handler.postDelayed(this::probeDashboard, 600);
                }
            });
        }, "quantflow-dashboard-probe").start();
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 42);
        }
    }

    private void showMaintenanceMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("Dashboard neu laden");
        popup.getMenu().add("Bot neu starten");
        popup.getMenu().add("Bot stoppen");
        popup.getMenu().add("Akku-Einstellungen");
        popup.setOnMenuItemClickListener(item -> handleMenuAction(String.valueOf(item.getTitle())));
        popup.show();
    }

    private boolean handleMenuAction(String t) {
        if (t.equals("Dashboard neu laden")) {
            loading.setVisibility(View.VISIBLE);
            loadingText.setText("Dashboard wird neu geladen …");
            waitForDashboard();
            return true;
        }
        if (t.equals("Bot neu starten")) {
            stopService(new Intent(this, BotService.class));
            handler.postDelayed(() -> { startBot(); loading.setVisibility(View.VISIBLE); waitForDashboard(); }, 700);
            return true;
        }
        if (t.equals("Bot stoppen")) {
            stopService(new Intent(this, BotService.class));
            loading.setVisibility(View.VISIBLE);
            loadingText.setText("Bot gestoppt");
            return true;
        }
        if (t.equals("Akku-Einstellungen")) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    @Override public void onResume() {
        super.onResume();
        if (BotService.running && web.getUrl() != null) web.reload();
    }

    @Override public void onBackPressed() {
        if (web.getVisibility() == View.VISIBLE && web.canGoBack()) web.goBack();
        else moveTaskToBack(true); // Bot läuft im Foreground-Service weiter.
    }
}
