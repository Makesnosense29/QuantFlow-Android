/* Transaction dates follow the device timezone, including DST. */
(()=>{'use strict';
const openDays=new Map();
function group(groups){
 const days=new Map();
 function add(g,x,type){const time=type==='BUY'?g.time:x.time,d=BotTime.date(time);
  const key=d?[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'):'unknown';
  if(!days.has(key))days.set(key,{key,label:d?new Intl.DateTimeFormat('de-DE',{weekday:'long',day:'2-digit',month:'2-digit',year:'numeric'}).format(d):'Zeit unbekannt',events:[]});
  days.get(key).events.push({g,x,type,time,epoch:d?d.getTime():0});
 }
 for(const g of groups){add(g,null,'BUY');for(const x of g.exits||[])add(g,x,'SELL')}
 return [...days.values()].sort((a,b)=>a.key==='unknown'?1:b.key==='unknown'?-1:b.key.localeCompare(a.key)).map(day=>({...day,events:day.events.sort((a,b)=>b.epoch-a.epoch)}));
}
function render(groups){return group(groups).map((day,index)=>{
 if(!openDays.has(day.key))openDays.set(day.key,index===0);
 const buys=day.events.filter(e=>e.type==='BUY').length;
 const cards=day.events.map(e=>e.type==='BUY'?'<div class="eventLabel">KAUF · '+esc(fmtTime(e.time))+'</div>'+tradeCard(e.g):
 `<div class="tradeCard saleEvent"><div class="eventLabel">VERKAUF · ${esc(fmtTime(e.time))}</div><b>${esc(e.g.symbol)} · ${esc(e.g.chain)}</b><p>${(Number(e.x.fraction)*100).toFixed(1)} % verkauft · ${Number(e.x.price_usd).toPrecision(8)} USD</p><p>${esc(reasonClean(e.x.reason||''))}</p><p class="${Number(e.x.pnl_eur)>=0?'positive':'negative'}">Verkaufs-P/L ${euro(e.x.pnl_eur)}</p><small>Kauf: ${esc(fmtTime(e.g.time))} · Kauf-ID ${esc(e.g.id)}<br>Der gesamte Trade-P/L einschließlich Einstiegskosten steht beim Kauf.</small></div>`).join('');
 return `<details class="tradeDay" data-day="${day.key}" ${openDays.get(day.key)?'open':''} ontoggle="if(this.isConnected)TradeDays.remember(this.dataset.day,this.open)"><summary>${esc(day.label)}<small>${buys} Käufe · ${day.events.length-buys} Verkäufe</small></summary><div class="dayEvents">${cards}</div></details>`;
 }).join('')}
window.TradeDays={group,render,remember:(key,open)=>openDays.set(key,open)};
})();
