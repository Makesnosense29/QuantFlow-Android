(()=>{'use strict';
const el=id=>document.getElementById(id), labels={solana:'Solana',ethereum:'Ethereum',base:'Base',bsc:'BNB Chain',arbitrum:'Arbitrum',polygon:'Polygon',avalanche:'Avalanche',optimism:'Optimism'};
let state=null, offline=true, selected='scanner', paused=matchMedia('(prefers-reduced-motion: reduce)').matches, spin=0,lastFrame=0,hits=[],options=[],rows=[],chartBusy=false,chartKey='',lastChart=0,hover=-1,chartData=null;
const modules={scanner:'Scanner',ai:'Lernmodell',risk:'Risikowächter',stats:'Trade-Statistik'};
const num=x=>Number(x||0).toLocaleString('de-DE'),price=x=>Number(x).toLocaleString('en-US',{maximumSignificantDigits:7}), clock=t=>window.BotTime.format(t,false);
function stale(){return offline||!state||state.stale||((state.worker_age_seconds??0)>90)}
function color(key){if(stale())return '#627089';if(key==='risk')return state.daily_halt||state.drawdown_halt?'#ffbf74':'#53efde';if(key==='ai')return '#b18aff';if(modules[key])return '#53efde';let c=state.coverage?.[key];return state.context?.[key]?.blocked?'#ffbf74':c?.quoted>0?'#53efde':'#627089'}
function info(){let d=state||{},c=d.coverage?.[selected],text='';if(c)text=`${labels[selected]} / ${num(c.selected)} ausgewählt · ${num(c.quoted)} mit Kurs · ${num(c.known)} bekannt. Kontext: ${d.context?.[selected]?.state||'unbekannt'}.`;
else if(selected==='scanner')text=`Scanner / ${num(d.discovery?.selected)} ausgewählt · Ziel ${num(d.discovery?.target||1000)} · ${num(d.discovery?.known)} bekannte Adressen. Letzter fertiger Scan: ${window.BotTime.format(d.scan_updated_epoch)} (${window.BotTime.zone()}).`;
else if(selected==='ai')text='Lernmodell / '+(d.ai?.message||'Noch keine Auswertung. Das Modell wird anhand abgeschlossener Trades geprüft.');
else if(selected==='risk')text=`Risikowächter / ${d.daily_halt||d.drawdown_halt?'Neue Einstiege gesperrt':'Keine gemeldete Risikosperre'} · Tagesverlustgrenze ${num(d.config?.max_daily_loss_eur)} € · ${num(d.position_count)} offene Positionen.`;
else if(selected==='stats')text=`Trade-Statistik / ${num(d.statistics?.closed)} abgeschlossene Trades · Netto ${num(d.statistics?.net_pnl)} € · Profit-Faktor ${d.statistics?.profit_factor==null?'—':price(d.statistics.profit_factor)}.`;
el('nodeInfo').textContent=(stale()?'DATEN VERALTET / Status nicht als aktuell bestätigt. ':'')+text;el('orbitStatus').textContent=stale()?'WARTE AUF AKTUELLE DATEN':'SYSTEM TELEMETRIE / PAPER';el('orbitCount').textContent=d.discovery?num(d.discovery.selected):'—';document.querySelectorAll('[data-node]').forEach(b=>{b.classList.toggle('selected',b.dataset.node===selected);b.setAttribute('aria-pressed',String(b.dataset.node===selected))})}
function setupCanvas(canvas){let r=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);if(canvas.width!==Math.round(r.width*d)||canvas.height!==Math.round(r.height*d)){canvas.width=Math.round(r.width*d);canvas.height=Math.round(r.height*d)}let ctx=canvas.getContext('2d');ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,r.width,r.height);return [ctx,r.width,r.height]}
// Deterministic brain sculpture, separate from factual telemetry and trade data.
let yaw=.22,tilt=-.12,zoom=1;
const neural=[],wires=[];
const rings=23,segments=28;
for(let side of [-1,1])for(let j=0;j<rings;j++)for(let k=0;k<segments;k++){
 const u=Math.PI*(j+.5)/rings,v=2*Math.PI*k/segments;
 const folds=1+.045*Math.sin(v*7+u*11)+.025*Math.cos(v*11-u*8);
 // Two hemispheres with a visible medial fissure and folded surfaces.
 const x=side*(.075+.57*(1+Math.cos(v))*Math.sin(u))*folds;
 const y=.91*Math.cos(u)*folds,z=.76*Math.sin(v)*Math.sin(u)*folds;
 const n=neural.length;neural.push({x,y,z,side,j,k});
 if(k)wires.push([n-1,n]);else if(j)wires.push([n-1,n]);
 if(j){wires.push([n-segments,n]);if(k%3===0)wires.push([n-segments+(k===segments-1?-1:1),n])}
}
function universe(t){if(!document.hidden&&!paused&&el('universe').getBoundingClientRect().bottom>0&&el('universe').getBoundingClientRect().top<innerHeight&&t-lastFrame>50){let dt=Math.min(100,t-lastFrame);lastFrame=t;spin+=dt*.00011;drawOrbit()}requestAnimationFrame(universe)}
function drawOrbit(){
 const [c,w,h]=setupCanvas(el('universe')),mobile=w<650,cx=w/2,cy=h*.43,scale=Math.min(w*(mobile?.22:.23),h*.32)*zoom;
 const rotation=yaw+spin*.14,cr=Math.cos(rotation),sr=Math.sin(rotation),ct=Math.cos(tilt),st=Math.sin(tilt);
 function project(p){let x=p.x*cr+p.z*sr,z=-p.x*sr+p.z*cr,y=p.y*ct-z*st;z=p.y*st+z*ct;const q=3.8/(3.8-z);return {x:cx+x*scale*q,y:cy-y*scale*q,z,q}}
 const pts=neural.map(project);hits=[];
 let halo=c.createRadialGradient(cx,cy,0,cx,cy,Math.max(w*.45,h*.45));halo.addColorStop(0,'#15608055');halo.addColorStop(.45,'#0b37552a');halo.addColorStop(1,'#07132100');c.fillStyle=halo;c.fillRect(0,0,w,h);
 // Depth grid and broad orbit traces.
 c.lineWidth=.55;for(let j=0;j<4;j++){c.strokeStyle='#5ccdea18';c.beginPath();c.ellipse(cx,cy+h*.08,scale*(1.65+j*.24),scale*(.3+j*.09),-.16,0,Math.PI*2);c.stroke()}
 const keys=[...Object.keys(labels),...Object.keys(modules)];
 const cards=keys.map((key,i)=>{let col=i<6?0:1,row=i%6,x=col?w-(mobile?49:96):(mobile?49:96),y=h*(.10+row*.12);return {key,x,y}});
 // Paths are decorative conduits. Endpoint colours alone encode live status.
 cards.forEach(({key,x,y},i)=>{
  let anchor=pts[(i*97+235)%pts.length],controlX=cx+(x<cx?-scale*.85:scale*.85),controlY=cy+(y-cy)*.16;
  c.strokeStyle=color(key)+(selected===key?'a0':'48');c.lineWidth=selected===key?1.1:.65;
  c.beginPath();c.moveTo(x,y);c.bezierCurveTo(controlX,y,controlX,controlY,anchor.x,anchor.y);c.stroke();
  if(!stale()){for(let j=0;j<2;j++){let t=(spin*.28+i*.071+j*.5)%1,q=1-t,px=q*q*q*x+3*q*q*t*controlX+3*q*t*t*controlX+t*t*t*anchor.x,py=q*q*q*y+3*q*q*t*y+3*q*t*t*controlY+t*t*t*anchor.y;c.fillStyle=color(key);c.shadowColor=color(key);c.shadowBlur=10;c.beginPath();c.arc(px,py,1.7,0,7);c.fill();c.shadowBlur=0}}
 });
 // Back faces dimmed, foreground lattice crisp.
 c.lineWidth=mobile?.45:.6;
 for(const [a,b] of wires){const p=pts[a],q=pts[b],depth=(p.z+q.z)/2,alpha=Math.max(.07,Math.min(.52,.24+depth*.23));c.strokeStyle=`rgba(99,228,242,${alpha})`;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);c.stroke()}
 pts.forEach((p,i)=>{if(i%2&&mobile)return;let front=p.z>0;c.fillStyle=front?'#a6ffffb0':'#62b2d045';c.beginPath();c.arc(p.x,p.y,front?.85:.55,0,7);c.fill()});
 // Sparse hubs brighten the folded mesh without pretending to be real neurons.
 for(let i=0;i<18;i++){let p=pts[(i*71+40)%pts.length];c.fillStyle=i%4===0?'#d9b7ff':'#b9ffff';c.shadowColor=i%4===0?'#b489ff':'#76edff';c.shadowBlur=12;c.beginPath();c.arc(p.x,p.y,1.6,0,7);c.fill();c.shadowBlur=0}
 cards.forEach(({key,x,y})=>{const hw=mobile?40:76,hh=mobile?15:21,co=color(key);c.fillStyle=selected===key?'#16364dea':'#0b2134eb';c.fillRect(x-hw,y-hh,hw*2,hh*2);c.strokeStyle=co+(selected===key?'cc':'70');c.lineWidth=.8;c.strokeRect(x-hw,y-hh,hw*2,hh*2);c.textAlign='left';c.fillStyle='#ccecf6';c.font=(mobile?'8':'11')+'px monospace';c.fillText(labels[key]||modules[key],x-hw+6,y-(mobile?2:4));c.fillStyle=co;c.font=(mobile?'7':'9')+'px monospace';let sub='';if(stale())sub='STATUS UNBEKANNT';else if(labels[key])sub=(state.coverage?.[key]?.quoted??0)+' mit Kurs';else if(key==='ai')sub='LOKALES LERNMODELL';else if(key==='risk')sub=state.daily_halt||state.drawdown_halt?'ENTRY GESPERRT':'LIMITS AKTIV';else if(key==='scanner')sub=(state.discovery?.selected||0)+' Kandidaten';else sub=(state.statistics?.closed||0)+' Abschlüsse';c.fillText(sub,x-hw+6,y+(mobile?8:11));hits.push({key,x,y,hw,hh})});
}
function populate(d){const previous=el('chartPool').value,found=new Map(options.filter(x=>x.manual).map(x=>[x.key,x]));
function add(chain,pool,token,symbol){if(!labels[chain]||!pool||!token)return;let key=[chain,pool,token].join('|');if(!found.has(key))found.set(key,{key,chain,pool,token,symbol})}
(d.positions||[]).forEach(p=>add(p.chain_id,p.pair_address,p.token,p.symbol));(d.near||[]).forEach(n=>{let p=n[1]||{};add(p.chainId,p.pairAddress,p.baseToken?.address,p.baseToken?.symbol)});options=[...found.values()].slice(0,40);
el('chartPool').replaceChildren(new Option(options.length?'Pool wählen …':'Noch keine Pools mit Adresse',''),...options.map(x=>new Option(`${x.symbol||x.token.slice(0,8)} / ${labels[x.chain]} / ${x.pool.slice(0,6)}…`,x.key)));
const automatic=el('chartAuto').checked;
const active=(d.positions||[]).map(p=>[p.chain_id,p.pair_address,p.token].join('|'));
const preferred=options.find(x=>active.includes(x.key));
const retained=options.find(x=>x.key===previous);
const choice=automatic?(active.includes(previous)?retained:preferred||retained||options.find(x=>!x.manual)||options[0]):retained;
el('chartPool').value=choice?.key||'';
if(el('chartPool').value!==previous){chartKey='';rows=[];chartData=null;hover=-1;drawCandles()}
if(!el('chartPool').value){el('chartStatus').textContent='Warte auf aktuelle Pools aus Positionen oder Scanner.';return}
if(!chartKey&&!document.hidden)fetchChart();}
function chartStatus(){
 if(chartBusy)return;
 const age=chartData?.fetched_at?Math.max(0,Math.floor(Date.now()/1000-chartData.fetched_at)):null;
 const duration={'1m':60,'5m':300,'15m':900,'1h':3600}[el('chartFrame').value];
 const latest=rows.at(-1),now=Date.now()/1000;
 const current=latest&&latest[0]<=now&&now<latest[0]+duration;
 el('chartStatus').textContent=(el('chartAuto').checked?'AUTO · ':'MANUELL · ')+(chartData?.error?chartData.error+' · ':'')+
 (age===null?'Noch kein bestätigter Kursabruf':`GeckoTerminal · Abruf vor ${age} s · `+(chartData?.stale||age>75?'VERALTET':'Quelle abgefragt'))+
 (latest?(current?' · LAUFENDE KERZE · '+Math.ceil(latest[0]+duration-now)+' s bis Intervallende':' · Letztes Kerzenintervall abgelaufen; warte auf neue Quelldaten'):' · Keine Kerzen verfügbar')+
 ' · Aktualisierung ca. 35 s; Quellenverzögerung möglich.';
}

async function fetchChart(){let p=options.find(x=>x.key===el('chartPool').value);if(!p||chartBusy)return;let frame=el('chartFrame').value,key=p.key+'|'+frame;chartBusy=true;lastChart=Date.now();el('chartRefresh').disabled=true;
if(key!==chartKey){rows=[];chartData=null;hover=-1;chartKey=key;drawCandles()}el('chartStatus').textContent='Kerzendaten werden geladen …';el('chartMeta').textContent=`${p.symbol||p.token.slice(0,8)} / ${labels[p.chain]} · ${frame} · USD · Pool ${p.pool}`;
try{let r=await fetch('/api/candles?'+new URLSearchParams({...p,frame}),{signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('HTTP '+r.status);let d=await r.json();if(el('chartPool').value+'|'+el('chartFrame').value!==key)return;rows=d.rows||[];chartData=d;drawCandles()}
catch(e){if(el('chartPool').value+'|'+el('chartFrame').value===key){chartData={...(chartData||{}),stale:true,error:'Kerzenabruf fehlgeschlagen'};drawCandles()}}
finally{chartBusy=false;el('chartRefresh').disabled=false;chartStatus();if(el('chartPool').value&&el('chartPool').value+'|'+el('chartFrame').value!==key&&!document.hidden)fetchChart()}}

function drawCandles(){const [c,w,h]=setupCanvas(el('candles'));el('chartEmpty').style.display=rows.length?'none':'grid';let left=10,right=w-76,top=18,bottom=h-63;c.font='9px monospace';c.lineWidth=.7;c.textAlign='left';
for(let i=0;i<5;i++){let y=top+(bottom-top)*i/4;c.strokeStyle='#20334b77';c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke()}
if(!rows.length){el('candleDetail').textContent='O —   H —   L —   C —   VOL —';return}const lo=Math.min(...rows.map(r=>r[3])),hi=Math.max(...rows.map(r=>r[2])),pad=Math.max((hi-lo)*.1,hi*.001),min=lo-pad,max=hi+pad,y=p=>bottom-(p-min)/(max-min)*(bottom-top),duration={'1m':60,'5m':300,'15m':900,'1h':3600}[el('chartFrame').value],start=rows[0][0]-duration,end=rows.at(-1)[0]+duration,x=t=>left+(t-start)/(end-start)*(right-left),cw=Math.max(.8,Math.min(10,(right-left)*duration/(end-start)*.64)),vmax=Math.max(...rows.map(r=>r[5]),1);
c.fillStyle='#829db6';for(let i=0;i<5;i++)c.fillText(price(max-(max-min)*i/4),right+7,top+(bottom-top)*i/4+3);
rows.forEach((r,i)=>{let xx=x(r[0]),co=r[4]>=r[1]?'#53efca':'#ff6191';c.strokeStyle=co;c.fillStyle=co;c.beginPath();c.moveTo(xx,y(r[2]));c.lineTo(xx,y(r[3]));c.stroke();c.fillRect(xx-cw/2,Math.min(y(r[1]),y(r[4])),cw,Math.max(1,Math.abs(y(r[1])-y(r[4]))));c.globalAlpha=.3;c.fillRect(xx-cw/2,h-24-r[5]/vmax*27,cw,r[5]/vmax*27);c.globalAlpha=1});
c.fillStyle='#829db6';c.textAlign='center';[0,Math.floor(rows.length/2),rows.length-1].forEach(i=>c.fillText(clock(rows[i][0]),Math.max(27,Math.min(right-15,x(rows[i][0]))),h-7));let r=rows[Math.min(rows.length-1,hover<0?rows.length-1:hover)];if(hover>=0){c.strokeStyle='#a6c0dbaa';c.setLineDash([3,3]);c.beginPath();c.moveTo(x(r[0]),top);c.lineTo(x(r[0]),h-24);c.stroke();c.setLineDash([])}el('candleDetail').textContent=`${window.BotTime.format(r[0])} (${window.BotTime.zone()}) · O ${price(r[1])}  H ${price(r[2])}  L ${price(r[3])}  C ${price(r[4])}  VOL $${price(r[5])}`;
el('candles')._geometry={x,rows};}
Object.entries({...labels,...modules}).forEach(([k,v])=>{let b=document.createElement('button');b.textContent=v;b.dataset.node=k;b.onclick=()=>{selected=k;info();drawOrbit()};el('nodeButtons').append(b)});Object.entries(labels).forEach(([k,v])=>el('manualChain').add(new Option(v,k)));
el('motion').textContent=paused?'Start':'Pause';el('motion').setAttribute('aria-pressed',String(paused));el('motion').onclick=()=>{paused=!paused;el('motion').textContent=paused?'Start':'Pause';el('motion').setAttribute('aria-pressed',String(paused))};
let pointer=null,dragged=false;
el('universe').addEventListener('pointerdown',e=>{pointer={id:e.pointerId,x:e.clientX,y:e.clientY};dragged=false;el('universe').setPointerCapture(e.pointerId)});
el('universe').addEventListener('pointermove',e=>{if(!pointer||pointer.id!==e.pointerId)return;const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;if(Math.abs(dx)+Math.abs(dy)>2)dragged=true;yaw+=dx*.008;tilt=Math.max(-.9,Math.min(.9,tilt+dy*.005));pointer.x=e.clientX;pointer.y=e.clientY;drawOrbit()});
function release(e){if(!pointer)return;if(!dragged){let r=el('universe').getBoundingClientRect(),hit=hits.find(p=>Math.abs(p.x-e.clientX+r.left)<p.hw&&Math.abs(p.y-e.clientY+r.top)<p.hh);if(hit){selected=hit.key;info()}}pointer=null;drawOrbit()}
el('universe').addEventListener('pointerup',release);el('universe').addEventListener('pointercancel',()=>pointer=null);
el('zoomIn').onclick=()=>{zoom=Math.min(1.45,zoom+.1);drawOrbit()};el('zoomOut').onclick=()=>{zoom=Math.max(.65,zoom-.1);drawOrbit()};el('resetView').onclick=()=>{zoom=1;yaw=.22;tilt=-.12;spin=0;drawOrbit()};
el('fullScene').onclick=async()=>{const panel=document.querySelector('.orbit-panel');try{if(document.fullscreenElement)await document.exitFullscreen();else if(panel.requestFullscreen)await panel.requestFullscreen();else{panel.classList.toggle('expanded-scene');el('fullScene').textContent=panel.classList.contains('expanded-scene')?'Schließen':'Vollbild'}drawOrbit()}catch(e){el('nodeInfo').textContent='Vollbild wurde vom Browser nicht freigegeben. Drehen und Zoom bleiben verfügbar.'}};
document.addEventListener('fullscreenchange',()=>{el('fullScene').textContent=document.fullscreenElement?'Schließen':'Vollbild';drawOrbit()});
el('candles').addEventListener('pointermove',e=>{if(!rows.length)return;let g=el('candles')._geometry,xx=e.clientX-el('candles').getBoundingClientRect().left;hover=rows.reduce((best,r,i)=>Math.abs(g.x(r[0])-xx)<Math.abs(g.x(rows[best][0])-xx)?i:best,0);drawCandles()});
el('chartRefresh').onclick=fetchChart;el('chartPool').onchange=()=>{el('chartAuto').checked=false;chartData=null;rows=[];hover=-1;drawCandles();fetchChart()};el('chartFrame').onchange=()=>{chartData=null;rows=[];hover=-1;drawCandles();fetchChart()};
el('manualLoad').onclick=()=>{let chain=el('manualChain').value,pool=el('manualPool').value.trim(),token=el('manualToken').value.trim();if(![pool,token].every(x=>/^[A-Za-z0-9]{20,100}$/.test(x))){el('chartStatus').textContent='Bitte gültige Pool- und Token-Adressen eingeben.';return}el('chartAuto').checked=false;let key=[chain,pool,token].join('|');options=options.filter(x=>x.key!==key);options.unshift({key,chain,pool,token,symbol:token.slice(0,8),manual:true});populate(state||{});el('chartPool').value=key;fetchChart()};
window.addEventListener('botdata',e=>{state=e.detail;offline=false;info();populate(state);drawOrbit()});window.addEventListener('botoffline',()=>{offline=true;info();drawOrbit()});window.addEventListener('resize',()=>{drawCandles();drawOrbit()});
el('chartAuto').onchange=()=>{populate(state||{});chartStatus()};
document.addEventListener('visibilitychange',()=>{if(!document.hidden){chartStatus();if(Date.now()-lastChart>=35000)fetchChart()}});
setInterval(()=>{if(document.hidden)return;chartStatus();if(!chartBusy&&Date.now()-lastChart>=35000&&el('chartPool').value)fetchChart()},1000);drawCandles();drawOrbit();requestAnimationFrame(universe);
})();
