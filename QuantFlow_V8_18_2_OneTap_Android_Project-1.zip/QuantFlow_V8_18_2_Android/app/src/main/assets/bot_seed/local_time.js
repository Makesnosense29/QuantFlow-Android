(()=>{'use strict';
function date(value){
 if(value instanceof Date)return Number.isFinite(value.getTime())?value:null;
 if(typeof value==='number')return value>0&&Number.isFinite(value)?new Date(value*1000):null;
 if(typeof value!=='string')return null;
 let s=value.trim().replace(' ','T');
 // Bot timestamps without a suffix are legacy UTC, never browser-local input.
 if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?$/.test(s))return null;
 if(!/(?:Z|[+-]\d{2}:?\d{2})$/.test(s))s+='Z';
 const d=new Date(s);return Number.isFinite(d.getTime())?d:null;
}
function zone(){return Intl.DateTimeFormat().resolvedOptions().timeZone||'Etc/UTC'}
function format(value,full=true){const d=date(value);if(!d||!Number.isFinite(d.getTime()))return '—';return new Intl.DateTimeFormat('de-DE',{...(full?{day:'2-digit',month:'2-digit',year:'numeric'}:{}),hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d)}
window.BotTime={format,date,zone};
function clock(){const e=document.getElementById('deviceClock');if(e)e.textContent='Gerätezeit '+format(new Date(),false)+' · '+zone()}
clock();setInterval(clock,1000);
})();
