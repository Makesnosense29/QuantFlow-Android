# QuantFlow V8.18.2-forward – Android APK-Projekt

Dieses Projekt verpackt die bestehende **V8.18.2-forward PAPER-Strategie** als Android-App.
Die Handelslogik und die Strategieparameter wurden nicht verändert. Android-spezifisch hinzugefügt wurden nur:

- Foreground-Service für dauerhaften Betrieb
- PARTIAL_WAKE_LOCK
- Start / Stop / Reload im App-Fenster
- lokales Dashboard im WebView auf `127.0.0.1:8766`
- beschreibbarer App-Datenordner statt Termux-Projektordner
- Python 3.13 über Chaquopy

## Wichtig

Die App bleibt **PAPER only**. Sie enthält keine Wallet- oder Echtgeld-Ausführung.
Die aktuelle Live-Historie deines Termux-Bots ist absichtlich nicht eingebettet, weil dieser Projektstand nur die Strategie- und Quellcode-Snapshots aus dem Chat enthält. Beim ersten Start beginnt die APK mit einem frischen Paper-State entsprechend `config.json`.

## Build in Android Studio

1. Projektordner in Android Studio öffnen.
2. JDK 17 verwenden.
3. Gradle Sync ausführen. Beim ersten Build werden Android- und Chaquopy-Abhängigkeiten aus dem Internet geladen.
4. `Build > Build APK(s)`.
5. Ergebnis: `app/build/outputs/apk/debug/app-debug.apk`.

Technischer Build-Stack: Android Gradle Plugin 8.9.2, Gradle 8.11.1, compile/target SDK 35, Chaquopy 16.1.0, Python 3.13, minSdk 24.

## Build über GitHub Actions

Die Datei `.github/workflows/build-apk.yml` ist enthalten. Projekt in ein GitHub-Repository legen und den Workflow **Build APK** ausführen. Danach das APK als Actions-Artefakt herunterladen.

## Android-Betrieb

Beim Öffnen startet die App den Paper-Bot als Foreground-Service. Die Benachrichtigung muss bestehen bleiben. Über den Button **Akku** die Android-App-Einstellungen öffnen und für zuverlässigen Langzeitbetrieb die Hintergrund-/Akku-Beschränkung für diese App lockern.

`Stop` beendet den Bot-Service. `Start` startet ihn wieder. Das Dashboard läuft ausschließlich lokal auf `127.0.0.1:8766`.

## Daten

Laufdaten liegen im privaten Android-App-Verzeichnis, darunter:

- `state.json`
- `trades.csv`
- `bot.log`
- `observations.jsonl`
- `scanner_snapshot.json`
- `universe.json`
- `strategies.sqlite3`
- `strategies_v818.sqlite3`

Beim App-Update sollen diese Laufdaten erhalten bleiben; die gebündelte `config.json` und die Dashboard-Dateien werden auf den mitgelieferten V8.18.2-Stand gesetzt.
